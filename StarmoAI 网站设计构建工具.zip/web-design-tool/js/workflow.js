// ============================================
// StarmoAI Design - 工作流引导系统
// ============================================

const WORKFLOW_STEPS = [
  {
    id: 'research',
    title: '需求调研',
    desc: '明确项目目标、目标用户、核心功能',
    checklist: [
      '确定网站类型（企业站/电商/博客/社区/工具）',
      '明确目标用户画像',
      '列出核心功能和页面需求',
      '分析竞品（至少2-3个）',
      '确定技术约束和性能目标',
    ]
  },
  {
    id: 'sitemap',
    title: '信息架构',
    desc: '规划网站结构、页面层级和导航逻辑',
    checklist: [
      '画出站点地图（页面层级关系）',
      '确定主导航结构',
      '规划用户核心路径（关键流程）',
      '确定面包屑导航需求',
      '标注页面间的跳转关系',
    ]
  },
  {
    id: 'wireframe',
    title: '线框图设计',
    desc: '用低保真原型确定布局和内容分区',
    checklist: [
      '确定页面栅格系统（12/16/24列）',
      '规划各页面的内容区块',
      '确定响应式断点（移动/平板/桌面）',
      '设计表单和交互流程',
      '与团队/客户确认线框图',
    ]
  },
  {
    id: 'visual',
    title: '视觉设计',
    desc: '确定配色、字体、间距、组件风格',
    checklist: [
      '确定主色、辅色、中性色',
      '选择字体方案（标题/正文/代码）',
      '定义间距系统（4/8/16/24/32px）',
      '设计按钮、输入框、卡片等组件',
      '确保色彩对比度满足无障碍标准',
    ]
  },
  {
    id: 'components',
    title: '组件搭建',
    desc: '从组件库拖拽搭建页面结构',
    checklist: [
      '搭建全局页头和页脚',
      '填充各页面的主体内容',
      '设置文字排版和层级',
      '添加图片和图标占位',
      '检查各元素间距和对齐',
    ]
  },
  {
    id: 'interaction',
    title: '交互与动画',
    desc: '添加动画效果、页面跳转和交互反馈',
    checklist: [
      '为关键元素添加入场动画',
      '设置按钮和链接的跳转关系',
      '添加hover/active微交互',
      '测试页面间的导航流程',
      '检查动画时序和节奏',
    ]
  },
  {
    id: 'responsive',
    title: '响应式适配',
    desc: '确保不同屏幕尺寸下的显示效果',
    checklist: [
      '测试375px移动端显示',
      '测试768px平板显示',
      '测试1440px+桌面显示',
      '调整字体大小断点',
      '处理溢出和换行问题',
    ]
  },
  {
    id: 'review',
    title: '审查与优化',
    desc: '最终检查、性能优化和导出',
    checklist: [
      '检查所有文字内容和错别字',
      '测试所有链接和跳转',
      '审查SEO信息（标题/描述/关键词）',
      '导出HTML代码',
      '准备部署上线',
    ]
  },
];

function openWorkflow() {
  const overlay = document.getElementById('workflowOverlay');
  if (!overlay) return;
  overlay.classList.add('active');
  renderWorkflow();
}

function closeWorkflow() {
  const overlay = document.getElementById('workflowOverlay');
  if (overlay) overlay.classList.remove('active');
}

function renderWorkflow() {
  const stepsContainer = document.getElementById('workflowSteps');
  const detailContainer = document.getElementById('workflowDetail');
  if (!stepsContainer || !detailContainer) return;

  // 左侧步骤列表
  stepsContainer.innerHTML = WORKFLOW_STEPS.map((step, i) => {
    const isActive = AppState.workflowStep === i;
    const checks = AppState.workflowChecks[step.id] || [];
    const isDone = checks.length === step.checklist.length;
    return `
      <div class="workflow-step-item ${isActive ? 'active' : ''} ${isDone ? 'done' : ''}" data-step="${i}">
        <div class="workflow-step-num">${isDone ? '✓' : i + 1}</div>
        <div class="workflow-step-info">
          <h4>${step.title}</h4>
          <p>${step.desc}</p>
        </div>
      </div>
    `;
  }).join('');

  // 绑定点击
  stepsContainer.querySelectorAll('.workflow-step-item').forEach(item => {
    item.addEventListener('click', () => {
      AppState.workflowStep = parseInt(item.dataset.step);
      renderWorkflow();
    });
  });

  // 右侧详情
  const step = WORKFLOW_STEPS[AppState.workflowStep];
  if (!step) return;

  const checks = AppState.workflowChecks[step.id] || [];
  detailContainer.innerHTML = `
    <h3>第 ${AppState.workflowStep + 1} 步：${step.title}</h3>
    <p>${step.desc}</p>
    <ul class="workflow-checklist">
      ${step.checklist.map((item, i) => {
        const isChecked = checks.includes(i);
        return `<li class="${isChecked ? 'checked' : ''}" data-check-step="${step.id}" data-check-idx="${i}">
          <div class="workflow-check-box"></div>
          <span>${item}</span>
        </li>`;
      }).join('')}
    </ul>
  `;

  detailContainer.querySelectorAll('.workflow-checklist li').forEach(li => {
    li.addEventListener('click', () => {
      const stepId = li.dataset.checkStep;
      const idx = parseInt(li.dataset.checkIdx);
      if (!AppState.workflowChecks[stepId]) AppState.workflowChecks[stepId] = [];
      const arr = AppState.workflowChecks[stepId];
      const pos = arr.indexOf(idx);
      if (pos >= 0) arr.splice(pos, 1); else arr.push(idx);
      renderWorkflow();
    });
  });
}

// ============ 导航图（站点地图可视化） ============
function openSitemap() {
  const overlay = document.getElementById('sitemapOverlay');
  if (!overlay) return;
  overlay.classList.add('active');
  renderSitemap();
}

function closeSitemap() {
  const overlay = document.getElementById('sitemapOverlay');
  if (overlay) overlay.classList.remove('active');
}

function renderSitemap() {
  const canvas = document.getElementById('sitemapCanvas');
  if (!canvas) return;

  // 简单树形布局
  const nodeW = 140, nodeH = 44, gapX = 40, gapY = 80;
  const positions = {};

  // 计算位置 - 简单层级布局
  const root = AppState.pages[0];
  if (!root) return;

  // 第一层
  positions[root.id] = { x: 100, y: 60 };

  // 第二层 - 所有链接到的页面
  let secondLevel = [];
  root.links.forEach(link => {
    if (!positions[link.toPageId]) {
      secondLevel.push(link.toPageId);
      positions[link.toPageId] = { x: 0, y: 60 + nodeH + gapY };
    }
  });

  // 未被链接的页面
  AppState.pages.forEach(p => {
    if (!positions[p.id]) {
      secondLevel.push(p.id);
      positions[p.id] = { x: 0, y: 60 + nodeH + gapY };
    }
  });

  // 均匀分布第二层
  const startX = 100;
  secondLevel.forEach((pid, i) => {
    positions[pid].x = startX + i * (nodeW + gapX);
  });

  // 渲染节点
  let nodesHtml = '';
  AppState.pages.forEach(page => {
    const pos = positions[page.id] || { x: 100, y: 60 };
    const isRoot = page.id === root.id;
    const isActive = page.id === AppState.currentPageId;
    nodesHtml += `<div class="sitemap-node ${isRoot ? 'root' : ''} ${isActive ? 'active' : ''}" data-sitemap-id="${page.id}" style="left:${pos.x}px;top:${pos.y}px;">${page.name}</div>`;
  });

  // 渲染连线
  let linksHtml = `<svg width="100%" height="100%">`;
  root.links.forEach(link => {
    const from = positions[root.id];
    const to = positions[link.toPageId];
    if (!from || !to) return;
    const x1 = from.x + nodeW/2, y1 = from.y + nodeH;
    const x2 = to.x + nodeW/2, y2 = to.y;
    const my = (y1 + y2) / 2;
    linksHtml += `<path d="M ${x1} ${y1} C ${x1} ${my}, ${x2} ${my}, ${x2} ${y2}" fill="none" stroke="var(--blue)" stroke-width="2" stroke-dasharray="6,4"/>`;
  });
  linksHtml += '</svg>';

  canvas.innerHTML = linksHtml + nodesHtml;

  // 绑定节点点击
  canvas.querySelectorAll('.sitemap-node').forEach(node => {
    node.addEventListener('click', () => {
 switchPage(node.dataset.sitemapId);
      closeSitemap();
      renderAll();
    });
    // 拖拽
    makeDraggable(node, canvas);
  });
}

function makeDraggable(node, container) {
  let startX, startY, origLeft, origTop;
  node.addEventListener('mousedown', (e) => {
    e.stopPropagation();
    startX = e.clientX; startY = e.clientY;
    origLeft = parseInt(node.style.left) || 0;
    origTop = parseInt(node.style.top) || 0;
    node.style.cursor = 'grabbing';
    const onMove = (e) => {
      node.style.left = (origLeft + e.clientX - startX) + 'px';
      node.style.top = (origTop + e.clientY - startY) + 'px';
    };
    const onUp = () => {
      node.style.cursor = 'grab';
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

// ============ 模板系统 ============
const TEMPLATES = [
  {
    name: '企业官网',
    desc: '经典企业首页布局',
    preview: 'corporate',
    pages: [
      {
        name: '首页', width: 1440, height: 900, backgroundColor: '#ffffff',
        elements: [
          { type: 'header', x: 0, y: 0, width: 1440, height: 64, styles: { backgroundColor: '#ffffff', borderWidth: 0 } },
          { type: 'hero', x: 0, y: 64, width: 1440, height: 500, styles: { backgroundColor: '#f8f9fa' } },
          { type: 'section', x: 60, y: 600, width: 1320, height: 260, styles: { backgroundColor: '#ffffff' } },
          { type: 'footer', x: 0, y: 880, width: 1440, height: 60, styles: { backgroundColor: '#1a1a2e', color: '#a0a0c0' } },
        ]
      }
    ]
  },
  {
    name: 'Landing Page',
    desc: '产品着陆页',
    preview: 'landing',
    pages: [
      {
        name: '着陆页', width: 1440, height: 900, backgroundColor: '#0f0f23',
        elements: [
          { type: 'nav', x: 0, y: 0, width: 1440, height: 56, styles: { backgroundColor: 'rgba(15,15,35,0.9)', color: '#ffffff' } },
          { type: 'hero', x: 100, y: 200, width: 600, height: 300, styles: { backgroundColor: 'transparent' } },
          { type: 'button', x: 100, y: 520, width: 180, height: 48, content: '免费试用', styles: { backgroundColor: '#e94560', color: '#ffffff', borderRadius: 8 } },
          { type: 'card', x: 800, y: 200, width: 500, height: 350, styles: { backgroundColor: '#1a1a3e', borderRadius: 12, boxShadow: '0 8px 32px rgba(0,0,0,0.3)' } },
        ]
      }
    ]
  },
  {
    name: '博客布局',
    desc: '文章列表和详情页',
    preview: 'blog',
    pages: [
      {
        name: '文章列表', width: 1440, height: 900, backgroundColor: '#f5f5f5',
        elements: [
          { type: 'header', x: 0, y: 0, width: 1440, height: 64, styles: { backgroundColor: '#ffffff' } },
          { type: 'heading', x: 100, y: 100, width: 400, height: 40, content: '最新文章', styles: { fontSize: 28, fontWeight: '700', color: '#333' } },
          { type: 'card', x: 100, y: 180, width: 380, height: 280, styles: { backgroundColor: '#ffffff', borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' } },
          { type: 'card', x: 530, y: 180, width: 380, height: 280, styles: { backgroundColor: '#ffffff', borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' } },
          { type: 'card', x: 960, y: 180, width: 380, height: 280, styles: { backgroundColor: '#ffffff', borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' } },
        ]
      }
    ]
  },
];

function openTemplates() {
  const overlay = document.getElementById('templateOverlay');
  if (!overlay) return;
  overlay.classList.add('active');
  renderTemplates();
}

function closeTemplates() {
  const overlay = document.getElementById('templateOverlay');
  if (overlay) overlay.classList.remove('active');
}

function renderTemplates() {
  const grid = document.getElementById('templateGrid');
  if (!grid) return;

  grid.innerHTML = TEMPLATES.map((tpl, i) => {
    return `
      <div class="template-card" data-tpl-idx="${i}">
        <div class="template-card-preview" style="background:#f0f0f0;">${renderTemplatePreview(tpl.preview)}</div>
        <div class="template-card-info">
          <h4>${tpl.name}</h4>
          <p>${tpl.desc}</p>
        </div>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('.template-card').forEach(card => {
    card.addEventListener('click', () => {
      const idx = parseInt(card.dataset.tplIdx);
      applyTemplate(TEMPLATES[idx]);
      closeTemplates();
    });
  });
}

function renderTemplatePreview(type) {
  switch(type) {
    case 'corporate':
      return `<div style="padding:12px;height:100%;"><div style="height:10%;background:#fff;border-bottom:2px solid #eee;margin-bottom:8px;"></div><div style="height:35%;background:#f8f9fa;border-radius:4px;margin-bottom:8px;display:flex;align-items:center;justify-content:center;color:#bbb;font-size:10px;">Hero</div><div style="height:30%;background:#fff;border-radius:4px;margin-bottom:8px;"></div><div style="height:10%;background:#1a1a2e;border-radius:4px;"></div></div>`;
    case 'landing':
      return `<div style="padding:12px;height:100%;background:#0f0f23;"><div style="height:8%;background:rgba(255,255,255,0.1);border-radius:4px;margin-bottom:10px;"></div><div style="height:40%;display:flex;gap:8px;margin-bottom:10px;"><div style="flex:1;display:flex;flex-direction:column;justify-content:center;"><div style="height:6px;width:70%;background:rgba(255,255,255,0.3);border-radius:3px;margin-bottom:6px;"></div><div style="height:4px;width:50%;background:rgba(255,255,255,0.15);border-radius:2px;margin-bottom:10px;"></div><div style="height:12px;width:30%;background:#e94560;border-radius:4px;"></div></div><div style="flex:1;background:rgba(255,255,255,0.05);border-radius:6px;"></div></div></div>`;
    case 'blog':
      return `<div style="padding:12px;height:100%;"><div style="height:10%;background:#fff;border-bottom:1px solid #eee;margin-bottom:8px;"></div><div style="height:5%;margin-bottom:8px;"><div style="height:100%;width:30%;background:#333;border-radius:3px;"></div></div><div style="display:flex;gap:6px;height:70%;"><div style="flex:1;background:#fff;border-radius:6px;"></div><div style="flex:1;background:#fff;border-radius:6px;"></div><div style="flex:1;background:#fff;border-radius:6px;"></div></div></div>`;
    default:
      return '';
  }
}

function applyTemplate(tpl) {
  // 清空当前项目
  AppState.pages = [];
  AppState.selectedIds = [];
  AppState.history = [];
  AppState.historyIndex = -1;

  // 创建模板页面
  tpl.pages.forEach(pageData => {
    const page = createPage(pageData.name, { width: pageData.width, height: pageData.height });
    page.backgroundColor = pageData.backgroundColor || '#ffffff';

    (pageData.elements || []).forEach(elData => {
      const el = createElement(elData.type, {
        x: elData.x, y: elData.y,
        width: elData.width, height: elData.height,
        content: elData.content,
        ...elData,
      });
      if (elData.styles) {
        Object.assign(el.styles, elData.styles);
      }
      addElementToPage(page.id, el);
    });
  });

  AppState.currentPageId = AppState.pages[0]?.id || null;
  saveHistory();
  renderAll();
  showToast(`已应用模板「${tpl.name}」`);
}

// ============ 导出HTML ============
function exportHTML() {
  let html = '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n';
  html += '<meta charset="UTF-8">\n';
  html += '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n';

  const page = AppState.pages[0];
  if (page?.meta?.title) html += `<title>${page.meta.title}</title>\n`;
  if (page?.meta?.description) html += `<meta name="description" content="${page.meta.description}">\n`;

  html += '\n<style>\n  * { margin: 0; padding: 0; box-sizing: border-box; }\n';
  html += '  body { font-family: sans-serif; }\n';

  // 动画关键帧
  html += `
  @keyframes wc-fadeIn { from { opacity:0; } to { opacity:1; } }
  @keyframes wc-slideInLeft { from { transform:translateX(-50px); opacity:0; } to { transform:translateX(0); opacity:1; } }
  @keyframes wc-slideInRight { from { transform:translateX(50px); opacity:0; } to { transform:translateX(0); opacity:1; } }
  @keyframes wc-slideInUp { from { transform:translateY(50px); opacity:0; } to { transform:translateY(0); opacity:1; } }
  @keyframes wc-slideInDown { from { transform:translateY(-50px); opacity:0; } to { transform:translateY(0); opacity:1; } }
  @keyframes wc-zoomIn { from { transform:scale(0.5); opacity:0; } to { transform:scale(1); opacity:1; } }
  @keyframes wc-bounceIn { 0% { transform:scale(0.3); opacity:0; } 50% { transform:scale(1.05); } 70% { transform:scale(0.9); } 100% { transform:scale(1); opacity:1; } }
  @keyframes wc-rotateIn { from { transform:rotate(-200deg); opacity:0; } to { transform:rotate(0); opacity:1; } }
  @keyframes wc-pulse { 0%,100% { transform:scale(1); } 50% { transform:scale(1.05); } }
  @keyframes wc-shake { 0%,100% { transform:translateX(0); } 10%,30%,50%,70%,90% { transform:translateX(-5px); } 20%,40%,60%,80% { transform:translateX(5px); } }
  `;

  html += '</style>\n</head>\n<body>\n';

  // 页面内容
  AppState.pages.forEach((page, pi) => {
    const sorted = [...page.elements].sort((a,b) => (a.zIndex||0) - (b.zIndex||0));
    html += `<div id="page-${page.id}" class="page" style="display:${pi===0?'block':'none'};width:100%;max-width:${page.width}px;min-height:${page.height}px;background:${page.backgroundColor};margin:0 auto;position:relative;overflow:hidden;">\n`;

    sorted.forEach(el => {
      if (!el.visible) return;
      const s = el.styles;
      let style = `position:absolute;left:${el.x}px;top:${el.y}px;width:${el.width}px;height:${el.height}px;background-color:${s.backgroundColor};color:${s.color};font-size:${s.fontSize}px;font-weight:${s.fontWeight};font-family:${s.fontFamily};text-align:${s.textAlign};border-radius:${s.borderRadius}px;border:${s.borderWidth}px ${s.borderStyle} ${s.borderColor};box-shadow:${s.boxShadow};padding:${s.padding}px;overflow:${s.overflow};line-height:${s.lineHeight};letter-spacing:${s.letterSpacing}px;opacity:${el.opacity};`;

      if (el.animations?.length) {
        el.animations.forEach(a => {
          style += `animation:wc-${a.type} ${a.duration}s ${a.easing} ${a.delay}s both;`;
        });
      }

      if (s.display === 'flex' || s.display === 'inline-flex') {
        style += `display:flex;flex-direction:${s.flexDirection};justify-content:${s.justifyContent};align-items:${s.alignItems};gap:${s.gap}px;`;
      }

      let tag = 'div';
      let content = '';
      let attrs = '';

      switch(el.type) {
        case 'text': case 'heading': case 'paragraph': content = el.content; break;
        case 'button': content = el.content || '按钮'; if (el.linkToPage) attrs = ` onclick="document.querySelectorAll('.page').forEach(p=>p.style.display='none');document.getElementById('page-${el.linkToPage}').style.display='block'"`; break;
        case 'link': content = el.content || '链接'; if (el.linkToPage) attrs = ` onclick="document.querySelectorAll('.page').forEach(p=>p.style.display='none');document.getElementById('page-${el.linkToPage}').style.display='block'"`; break;
        case 'canvas-drawing': content = el.drawingSvg || ''; break;
        case 'divider': style += 'height:2px;'; break;
      }

      html += `  <${tag} style="${style}"${attrs}>${content}</${tag}>\n`;
    });

    html += '</div>\n';
  });

  html += '\n<script>\n  // 页面导航\n';
  html += '</script>\n';
  html += '</body>\n</html>';

  // 下载
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'starmoai-design-export.html';
  a.click();
  URL.revokeObjectURL(url);
  showToast('HTML已导出', 'success');
}

// ============ 保存/加载项目 ============
function saveProject() {
  const data = {
    version: 1,
    pages: AppState.pages,
    workflowChecks: AppState.workflowChecks,
    workflowStep: AppState.workflowStep,
  };
  localStorage.setItem('starmoai_project', JSON.stringify(data));
  showToast('项目已保存', 'success');
}

function loadProject() {
 const raw = localStorage.getItem('starmoai_project');
  if (!raw) return false;
  try {
    const data = JSON.parse(raw);
    AppState.pages = data.pages || [];
    AppState.workflowChecks = data.workflowChecks || {};
    AppState.workflowStep = data.workflowStep || 0;
    AppState.currentPageId = AppState.pages[0]?.id || null;
    AppState.selectedIds = [];
    saveHistory();
    return true;
  } catch(e) {
    return false;
  }
}

// ============ 右键菜单 ============
function initContextMenu() {
  const menu = document.getElementById('contextMenu');
  if (!menu) return;

  document.addEventListener('contextmenu', (e) => {
    const elTarget = e.target.closest('.canvas-element');
    if (!elTarget) { menu.classList.remove('active'); return; }

    e.preventDefault();
    const elId = elTarget.dataset.elId;
    if (!AppState.selectedIds.includes(elId)) {
      AppState.selectedIds = [elId];
      renderCanvas(); renderLayers(); renderProperties();
    }

    menu.style.left = e.clientX + 'px';
    menu.style.top = e.clientY + 'px';
    menu.classList.add('active');
  });

  document.addEventListener('click', () => menu.classList.remove('active'));

  // 菜单操作
  menu.querySelectorAll('.context-menu-item').forEach(item => {
    item.addEventListener('click', () => {
      const action = item.dataset.action;
      if (!action) return;
      switch(action) {
        case 'copy': AppState.clipboard = { type: 'copy', ids: [...AppState.selectedIds] }; showToast('已复制'); break;
        case 'paste': pasteElements(); break;
        case 'duplicate': duplicateElements(AppState.selectedIds); break;
        case 'delete': deleteElements(AppState.selectedIds); break;
        case 'front': AppState.selectedIds.forEach(id => bringToFront(id)); break;
        case 'back': AppState.selectedIds.forEach(id => sendToBack(id)); break;
        case 'forward': AppState.selectedIds.forEach(id => bringForward(id)); break;
        case 'backward': AppState.selectedIds.forEach(id => sendBackward(id)); break;
        case 'lock': AppState.selectedIds.forEach(id => { const el = getElementById(id); if (el) el.locked = !el.locked; }); renderAll(); break;
      }
      menu.classList.remove('active');
    });
  });
}

function pasteElements() {
  if (!AppState.clipboard) { showToast('剪贴板为空', 'info'); return; }
  if (AppState.clipboard.type === 'copy') {
    duplicateElements(AppState.clipboard.ids);
  }
}

// ============ 快捷键 ============
function initShortcuts() {
  document.addEventListener('keydown', (e) => {
    // 如果在输入框中，忽略
    if (['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName) || e.target.contentEditable === 'true') return;

    const ctrl = e.ctrlKey || e.metaKey;

    if (e.key === 'v' || e.key === 'V') { AppState.tool = 'select'; updateToolButtons(); }
    if (e.key === 'r' || e.key === 'R') { if (!ctrl) { AppState.tool = 'rect'; updateToolButtons(); } }
    if (e.key === 'o' || e.key === 'O') { if (!ctrl) { AppState.tool = 'circle'; updateToolButtons(); } }
    if (e.key === 'l' || e.key === 'L') { if (!ctrl) { AppState.tool = 'line'; updateToolButtons(); } }
    if (e.key === 'p' || e.key === 'P') { if (!ctrl) { AppState.tool = 'pen'; updateToolButtons(); } }
    if (e.key === 'Delete' || e.key === 'Backspace') { if (AppState.selectedIds.length > 0) { e.preventDefault(); deleteElements(AppState.selectedIds); } }
    if (ctrl && e.key === 'z') { e.preventDefault(); undo(); }
    if (ctrl && e.key === 'y') { e.preventDefault(); redo(); }
    if (ctrl && e.key === 'c') { if (AppState.selectedIds.length > 0) { e.preventDefault(); AppState.clipboard = { type: 'copy', ids: [...AppState.selectedIds] }; showToast('已复制'); } }
    if (ctrl && e.key === 'v') { if (AppState.clipboard) { e.preventDefault(); pasteElements(); } }
    if (ctrl && e.key === 'd') { if (AppState.selectedIds.length > 0) { e.preventDefault(); duplicateElements(AppState.selectedIds); } }
    if (ctrl && e.key === 'a') { e.preventDefault(); const page = getCurrentPage(); if (page) { AppState.selectedIds = page.elements.map(el => el.id); renderCanvas(); renderLayers(); renderProperties(); } }
    if (ctrl && e.key === 's') { e.preventDefault(); saveProject(); }
    if (e.key === 'Escape') {
      AppState.selectedIds = [];
      AppState.tool = 'select';
      updateToolButtons();
      renderAll();
    }
    // 方向键微调
    if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) {
      if (AppState.selectedIds.length > 0) {
        e.preventDefault();
        const dx = e.key === 'ArrowLeft' ? -1 : e.key === 'ArrowRight' ? 1 : 0;
        const dy = e.key === 'ArrowUp' ? -1 : e.key === 'ArrowDown' ? 1 : 0;
        const step = e.shiftKey ? 10 : 1;
        moveElements(AppState.selectedIds, dx * step, dy * step);
        saveHistory();
        renderCanvas();
        renderProperties();
      }
    }
    // +/- 缩放
    if (e.key === '=' || e.key === '+') { AppState.zoom = clamp(AppState.zoom + 0.1, 0.1, 3); renderCanvas(); }
    if (e.key === '-') { AppState.zoom = clamp(AppState.zoom - 0.1, 0.1, 3); renderCanvas(); }
    if (e.key === '0' && ctrl) { e.preventDefault(); AppState.zoom = 1; renderCanvas(); }
  });
}

console.log('StarmoAI Design 工作流系统已加载');
