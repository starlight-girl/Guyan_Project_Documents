// ============================================
// StarmoAI Design - 核心引擎
// 纯手搓，零外部依赖
// ============================================

// ============ 全局状态管理 ============
const AppState = {
  pages: [],           // 所有页面
  currentPageId: null, // 当前页面ID
  selectedIds: [],     // 选中的元素ID数组
  clipboard: null,     // 剪贴板
  zoom: 1,             // 缩放比例
  panX: 0, panY: 0,   // 画布平移
  tool: 'select',      // 当前工具: select, draw, rect, circle, line, text, pen
  history: [],         // 撤销历史
  historyIndex: -1,    // 当前历史位置
  maxHistory: 50,      // 最大历史记录
  isDragging: false,
  isResizing: false,
  isDrawing: false,
  isMultiSelecting: false,
  guides: [],          // 辅助线
  showGuides: true,
  snapToGrid: true,
  gridSize: 10,
  drawingColor: '#e94560',
  drawingWidth: 2,
  drawingPoints: [],   // 画笔点
  workflowStep: 0,     // 工作流进度
  workflowChecks: {},  // 工作流勾选状态
};

// ============ 唯一ID生成器 ============
let _idCounter = 0;
function genId(prefix = 'el') {
  return `${prefix}_${Date.now()}_${++_idCounter}`;
}

// ============ 工具函数 ============
function clamp(val, min, max) { return Math.max(min, Math.min(max, val)); }
function deepClone(obj) { return JSON.parse(JSON.stringify(obj)); }
function dist(x1, y1, x2, y2) { return Math.sqrt((x2-x1)**2 + (y2-y1)**2); }

// ============ Toast 通知 ============
function showToast(msg, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.3s'; setTimeout(() => toast.remove(), 300); }, 2500);
}

// ============ 页面管理 ============
function createPage(name, opts = {}) {
  const page = {
    id: genId('page'),
    name: name || '未命名页面',
    width: opts.width || 1440,
    height: opts.height || 900,
    elements: [],
    backgroundColor: '#ffffff',
    links: [],  // 跳转链接 [{fromId, toPageId, label}]
    meta: { title: '', description: '', keywords: '' },
  };
  AppState.pages.push(page);
  if (!AppState.currentPageId) AppState.currentPageId = page.id;
  return page;
}

function getCurrentPage() {
  return AppState.pages.find(p => p.id === AppState.currentPageId);
}

function deletePage(pageId) {
  if (AppState.pages.length <= 1) { showToast('至少保留一个页面', 'error'); return; }
  const idx = AppState.pages.findIndex(p => p.id === pageId);
  if (idx === -1) return;
  AppState.pages.splice(idx, 1);
  if (AppState.currentPageId === pageId) {
    AppState.currentPageId = AppState.pages[0]?.id || null;
    AppState.selectedIds = [];
  }
  // 删除相关链接
  AppState.pages.forEach(p => {
    p.links = p.links.filter(l => l.toPageId !== pageId);
  });
}

function switchPage(pageId) {
  if (!AppState.pages.find(p => p.id === pageId)) return;
  AppState.currentPageId = pageId;
  AppState.selectedIds = [];
  renderCanvasTabs();
  renderCanvas();
  renderNavTree();
  renderProperties();
}

// ============ 元素管理 ============
function createElement(type, opts = {}) {
  const el = {
    id: genId('el'),
    type, // 'box','text','image','button','input','nav','container','link','list','form','table','svg-shape','canvas-drawing'
    x: opts.x ?? 100,
    y: opts.y ?? 100,
    width: opts.width ?? (type === 'text' ? 200 : 120),
    height: opts.height ?? (type === 'text' ? 40 : 80),
    rotation: 0,
    opacity: 1,
    visible: true,
    locked: false,
    zIndex: Date.now(),
    // 样式
    styles: {
      backgroundColor: opts.backgroundColor || (type === 'button' ? '#e94560' : '#f0f0f0'),
      color: opts.color || '#333333',
      fontSize: opts.fontSize || 14,
      fontWeight: opts.fontWeight || 'normal',
      fontFamily: opts.fontFamily || 'sans-serif',
      textAlign: opts.textAlign || 'left',
      borderRadius: opts.borderRadius || (type === 'button' ? 6 : 0),
      borderWidth: opts.borderWidth || 0,
      borderColor: opts.borderColor || '#cccccc',
      borderStyle: opts.borderStyle || 'solid',
      boxShadow: opts.boxShadow || 'none',
      padding: opts.padding || 0,
      margin: 0,
      overflow: 'visible',
      lineHeight: opts.lineHeight || 1.4,
      letterSpacing: 0,
      backgroundImage: '',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      display: 'block',
      flexDirection: 'row',
      justifyContent: 'flex-start',
      alignItems: 'center',
      gap: 0,
      cursor: type === 'button' ? 'pointer' : 'default',
    },
    // 内容
    content: opts.content || (type === 'text' ? '双击编辑文本' : ''),
    placeholder: opts.placeholder || '',
    href: opts.href || '',
    linkToPage: opts.linkToPage || '',
    // 子元素（用于容器）
    children: [],
    // 动画
    animations: [],
    // 名称
    name: opts.name || getDefaultName(type),
  };
  return el;
}

function getDefaultName(type) {
  const names = {
    box: '矩形', text: '文本', image: '图片', button: '按钮',
    input: '输入框', nav: '导航栏', container: '容器',
    link: '链接', list: '列表', form: '表单', table: '表格',
    'svg-shape': '形状', 'canvas-drawing': '手绘',
    heading: '标题', paragraph: '段落', divider: '分割线',
    icon: '图标', card: '卡片', hero: 'Hero区',
    header: '页头', footer: '页脚', section: '区块',
  };
  return names[type] || '元素';
}

function addElementToPage(pageId, element) {
  const page = AppState.pages.find(p => p.id === pageId);
  if (!page) return;
  page.elements.push(element);
  saveHistory();
}

function getElementById(elId) {
  const page = getCurrentPage();
  if (!page) return null;
  return page.elements.find(e => e.id === elId) || null;
}

function deleteElements(ids) {
  const page = getCurrentPage();
  if (!page) return;
  page.elements = page.elements.filter(e => !ids.includes(e.id));
  AppState.selectedIds = AppState.selectedIds.filter(id => !ids.includes(id));
  saveHistory();
  renderCanvas();
  renderLayers();
  renderProperties();
}

function duplicateElements(ids) {
  const page = getCurrentPage();
  if (!page) return;
  const newIds = [];
  ids.forEach(id => {
    const el = page.elements.find(e => e.id === id);
    if (!el) return;
    const dup = deepClone(el);
    dup.id = genId('el');
    dup.x += 20;
    dup.y += 20;
    dup.name = el.name + ' 副本';
    dup.zIndex = Date.now();
    page.elements.push(dup);
    newIds.push(dup.id);
  });
  AppState.selectedIds = newIds;
  saveHistory();
  renderCanvas();
  renderLayers();
  renderProperties();
}

function moveElements(ids, dx, dy) {
  const page = getCurrentPage();
  if (!page) return;
  ids.forEach(id => {
    const el = page.elements.find(e => e.id === id);
    if (!el || el.locked) return;
    el.x += dx;
    el.y += dy;
  });
}

// ============ 历史记录（撤销/重做） ============
function saveHistory() {
  const snapshot = deepClone(AppState.pages);
 AppState.history = AppState.history.slice(0, AppState.historyIndex + 1);
  AppState.history.push(snapshot);
  if (AppState.history.length > AppState.maxHistory) AppState.history.shift();
  AppState.historyIndex = AppState.history.length - 1;
}

function undo() {
  if (AppState.historyIndex <= 0) { showToast('没有更多操作可撤销', 'info'); return; }
  AppState.historyIndex--;
  AppState.pages = deepClone(AppState.history[AppState.historyIndex]);
  if (!AppState.pages.find(p => p.id === AppState.currentPageId)) {
    AppState.currentPageId = AppState.pages[0]?.id || null;
  }
  AppState.selectedIds = [];
  renderAll();
}

function redo() {
  if (AppState.historyIndex >= AppState.history.length - 1) { showToast('没有更多操作可重做', 'info'); return; }
  AppState.historyIndex++;
  AppState.pages = deepClone(AppState.history[AppState.historyIndex]);
  AppState.selectedIds = [];
  renderAll();
}

// ============ 对齐辅助 ============
function getSnapGuides(movingEls, page) {
  if (!AppState.showGuides) return [];
  const guides = [];
  const allEls = page.elements.filter(e => !movingEls.includes(e) && e.visible && !e.locked);
  
  movingEls.forEach(mEl => {
    const mLeft = mEl.x, mRight = mEl.x + mEl.width;
    const mTop = mEl.y, mBottom = mEl.y + mEl.height;
    const mCX = mEl.x + mEl.width/2, mCY = mEl.y + mEl.height/2;
    const threshold = 5;

    allEls.forEach(el => {
      const eLeft = el.x, eRight = el.x + el.width;
      const eTop = el.y, eBottom = el.y + el.height;
      const eCX = el.x + el.width/2, eCY = el.y + el.height/2;

      // 垂直辅助线（X对齐）
      if (Math.abs(mLeft - eLeft) < threshold) guides.push({ type: 'v', pos: eLeft, moveEl: mEl, prop: 'x', val: eLeft - mEl.x });
      if (Math.abs(mRight - eRight) < threshold) guides.push({ type: 'v', pos: eRight, moveEl: mEl, prop: 'x', val: eRight - mEl.width - mEl.x });
      if (Math.abs(mLeft - eRight) < threshold) guides.push({ type: 'v', pos: eRight, moveEl: mEl, prop: 'x', val: eRight - mEl.x });
      if (Math.abs(mRight - eLeft) < threshold) guides.push({ type: 'v', pos: eLeft, moveEl: mEl, prop: 'x', val: eLeft - mEl.width - mEl.x });
      if (Math.abs(mCX - eCX) < threshold) guides.push({ type: 'v', pos: eCX, moveEl: mEl, prop: 'x', val: eCX - mEl.width/2 - mEl.x });

      // 水平辅助线（Y对齐）
      if (Math.abs(mTop - eTop) < threshold) guides.push({ type: 'h', pos: eTop, moveEl: mEl, prop: 'y', val: eTop - mEl.y });
      if (Math.abs(mBottom - eBottom) < threshold) guides.push({ type: 'h', pos: eBottom, moveEl: mEl, prop: 'y', val: eBottom - mEl.height - mEl.y });
      if (Math.abs(mTop - eBottom) < threshold) guides.push({ type: 'h', pos: eBottom, moveEl: mEl, prop: 'y', val: eBottom - mEl.y });
      if (Math.abs(mBottom - eTop) < threshold) guides.push({ type: 'h', pos: eTop, moveEl: mEl, prop: 'y', val: eTop - mEl.height - mEl.y });
      if (Math.abs(mCY - eCY) < threshold) guides.push({ type: 'h', pos: eCY, moveEl: mEl, prop: 'y', val: eCY - mEl.height/2 - mEl.y });

      // 画布边缘对齐
      if (Math.abs(mLeft - 0) < threshold) guides.push({ type: 'v', pos: 0, moveEl: mEl, prop: 'x', val: -mEl.x });
      if (Math.abs(mTop - 0) < threshold) guides.push({ type: 'h', pos: 0, moveEl: mEl, prop: 'y', val: -mEl.y });
      if (Math.abs(mRight - page.width) < threshold) guides.push({ type: 'v', pos: page.width, moveEl: mEl, prop: 'x', val: page.width - mEl.width - mEl.x });
      if (Math.abs(mBottom - page.height) < threshold) guides.push({ type: 'h', pos: page.height, moveEl: mEl, prop: 'y', val: page.height - mEl.height - mEl.y });
    });
  });

  // 去重：同一个方向只保留最近的
  const hGuides = guides.filter(g => g.type === 'h');
  const vGuides = guides.filter(g => g.type === 'v');
  return [...hGuides.slice(0, 2), ...vGuides.slice(0, 2)];
}

function applySnaps(guides) {
  const applied = new Set();
  guides.forEach(g => {
    const key = `${g.moveEl.id}_${g.type}`;
    if (applied.has(key)) return;
    applied.add(key);
    g.moveEl[g.prop] += g.val;
  });
  return guides;
}

// ============ 多元素对齐 ============
function alignElements(alignment) {
  const page = getCurrentPage();
  if (!page || AppState.selectedIds.length < 2) return;
  const els = AppState.selectedIds.map(id => page.elements.find(e => e.id === id)).filter(Boolean);
  if (els.length < 2) return;

  const bounds = getElementsBounds(els);
  els.forEach(el => {
    switch(alignment) {
      case 'left': el.x = bounds.minX; break;
      case 'right': el.x = bounds.maxX - el.width; break;
      case 'top': el.y = bounds.minY; break;
      case 'bottom': el.y = bounds.maxY - el.height; break;
      case 'centerH': el.x = bounds.cx - el.width/2; break;
      case 'centerV': el.y = bounds.cy - el.height/2; break;
      case 'distributeH': break; // handled separately
      case 'distributeV': break;
    }
  });

  if (alignment === 'distributeH') {
    const sorted = [...els].sort((a,b) => a.x - b.x);
    const totalWidth = sorted.reduce((s, e) => s + e.width, 0);
    const gap = (bounds.maxX - bounds.minX - totalWidth) / (sorted.length - 1);
    let x = bounds.minX;
    sorted.forEach(el => { el.x = x; x += el.width + gap; });
  }
  if (alignment === 'distributeV') {
    const sorted = [...els].sort((a,b) => a.y - b.y);
    const totalHeight = sorted.reduce((s, e) => s + e.height, 0);
    const gap = (bounds.maxY - bounds.minY - totalHeight) / (sorted.length - 1);
    let y = bounds.minY;
    sorted.forEach(el => { el.y = y; y += el.height + gap; });
  }

  saveHistory();
  renderCanvas();
  renderProperties();
}

function getElementsBounds(els) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  els.forEach(el => {
    minX = Math.min(minX, el.x);
    minY = Math.min(minY, el.y);
    maxX = Math.max(maxX, el.x + el.width);
    maxY = Math.max(maxY, el.y + el.height);
  });
  return { minX, minY, maxX, maxY, cx: (minX+maxX)/2, cy: (minY+maxY)/2 };
}

// ============ 层级管理 ============
function bringForward(id) {
  const page = getCurrentPage(); if (!page) return;
  const idx = page.elements.findIndex(e => e.id === id);
  if (idx < 0 || idx >= page.elements.length - 1) return;
  [page.elements[idx], page.elements[idx+1]] = [page.elements[idx+1], page.elements[idx]];
  saveHistory(); renderCanvas(); renderLayers();
}

function sendBackward(id) {
  const page = getCurrentPage(); if (!page) return;
  const idx = page.elements.findIndex(e => e.id === id);
  if (idx <= 0) return;
  [page.elements[idx], page.elements[idx-1]] = [page.elements[idx-1], page.elements[idx]];
  saveHistory(); renderCanvas(); renderLayers();
}

function bringToFront(id) {
  const page = getCurrentPage(); if (!page) return;
  const idx = page.elements.findIndex(e => e.id === id);
  if (idx < 0) return;
  const [el] = page.elements.splice(idx, 1);
  page.elements.push(el);
  saveHistory(); renderCanvas(); renderLayers();
}

function sendToBack(id) {
  const page = getCurrentPage(); if (!page) return;
  const idx = page.elements.findIndex(e => e.id === id);
  if (idx < 0) return;
  const [el] = page.elements.splice(idx, 1);
  page.elements.unshift(el);
  saveHistory(); renderCanvas(); renderLayers();
}

console.log('StarmoAI Design 核心引擎已加载');
