// ============================================
// StarmoAI Design - 交互系统
// 拖拽、缩放、绘图、多选
// ============================================

let dragState = null;
let resizeState = null;
let drawState = null;
let multiSelectState = null;
let canvasDragState = null;

function bindCanvasEvents() {
  const wrapper = document.getElementById('canvasWrapper');
  if (!wrapper) return;
  const pageInner = wrapper.querySelector('.canvas-page-inner');
  if (!pageInner) return;

  // 元素点击和拖拽
  pageInner.addEventListener('mousedown', onCanvasMouseDown);
}

function getCanvasCoords(e) {
  const viewport = document.getElementById('canvasViewport');
  if (!viewport) return { x: 0, y: 0 };
  const rect = viewport.getBoundingClientRect();
  return {
    x: (e.clientX - rect.left - AppState.panX) / AppState.zoom,
    y: (e.clientY - rect.top - AppState.panY) / AppState.zoom,
  };
}

function onCanvasMouseDown(e) {
  const page = getCurrentPage();
  if (!page) return;

  const target = e.target;

  // 调整大小手柄
  if (target.classList.contains('resize-handle')) {
 e.preventDefault();
    const elId = target.dataset.elId;
    const handle = target.dataset.handle;
    const el = getElementById(elId);
    if (!el) return;
    resizeState = {
      elId, handle,
      startX: e.clientX, startY: e.clientY,
      origX: el.x, origY: el.y,
      origW: el.width, origH: el.height,
    };
    document.addEventListener('mousemove', onResizeMove);
    document.addEventListener('mouseup', onResizeEnd);
    return;
  }

  // 元素点击
  const elTarget = target.closest('.canvas-element');
  if (elTarget && AppState.tool === 'select') {
    e.preventDefault();
    const elId = elTarget.dataset.elId;
    const el = getElementById(elId);
    if (!el) return;

    // Shift多选
    if (e.shiftKey) {
      const idx = AppState.selectedIds.indexOf(elId);
      if (idx >= 0) {
        AppState.selectedIds.splice(idx, 1);
      } else {
        AppState.selectedIds.push(elId);
      }
    } else if (!AppState.selectedIds.includes(elId)) {
      AppState.selectedIds = [elId];
    }

    renderCanvas();
    renderLayers();
    renderProperties();

    // 开始拖拽
    if (!el.locked) {
      const coords = getCanvasCoords(e);
      dragState = {
        elIds: [...AppState.selectedIds],
        startX: e.clientX, startY: e.clientY,
        startEls: AppState.selectedIds.map(id => {
          const sel = getElementById(id);
          return sel ? { id, x: sel.x, y: sel.y } : null;
        }).filter(Boolean),
        moved: false,
      };
      document.addEventListener('mousemove', onDragMove);
      document.addEventListener('mouseup', onDragEnd);
    }
    return;
  }

  // 画布空白区域点击 - 框选或取消选择
  if ((target.classList.contains('canvas-page-inner') || target.classList.contains('canvas-page')) && AppState.tool === 'select') {
    e.preventDefault();

    if (!e.shiftKey) {
      AppState.selectedIds = [];
      renderCanvas();
      renderLayers();
      renderProperties();
    }

    // 开始框选
    const coords = getCanvasCoords(e);
    multiSelectState = {
      startX: coords.x, startY: coords.y,
      currentX: coords.x, currentY: coords.y,
    };
    AppState.isMultiSelecting = true;
    AppState.selectBox = { x: coords.x, y: coords.y, w: 0, h: 0 };
    document.addEventListener('mousemove', onMultiSelectMove);
    document.addEventListener('mouseup', onMultiSelectEnd);
    renderCanvas();
    return;
  }

  // 绘图工具
  if (AppState.tool !== 'select') {
    e.preventDefault();
    const coords = getCanvasCoords(e);
    startDrawing(coords, e);
  }
}

// ============ 拖拽 ============
function onDragMove(e) {
  if (!dragState) return;
  const dx = (e.clientX - dragState.startX) / AppState.zoom;
  const dy = (e.clientY - dragState.startY) / AppState.zoom;

  if (Math.abs(dx) > 2 || Math.abs(dy) > 2) dragState.moved = true;
  if (!dragState.moved) return;

  const page = getCurrentPage();
  if (!page) return;

  // 移动元素
  dragState.startEls.forEach(se => {
    const el = page.elements.find(el => el.id === se.id);
    if (el && !el.locked) {
      el.x = se.x + dx;
      el.y = se.y + dy;
    }
  });

  // 辅助线
  const movingEls = dragState.elIds.map(id => page.elements.find(e => e.id === id)).filter(Boolean);
 AppState.guides = getSnapGuides(movingEls, page);
  applySnaps(AppState.guides);

  renderCanvas();
}

function onDragEnd(e) {
  if (dragState) {
    if (dragState.moved) saveHistory();
    AppState.guides = [];
    dragState = null;
    renderCanvas();
    renderProperties();
  }
  document.removeEventListener('mousemove', onDragMove);
  document.removeEventListener('mouseup', onDragEnd);
}

// ============ 调整大小 ============
function onResizeMove(e) {
  if (!resizeState) return;
  const dx = (e.clientX - resizeState.startX) / AppState.zoom;
  const dy = (e.clientY - resizeState.startY) / AppState.zoom;
  const el = getElementById(resizeState.elId);
  if (!el) return;

  const { handle, origX, origY, origW, origH } = resizeState;

  switch(handle) {
    case 'se': el.width = Math.max(10, origW + dx); el.height = Math.max(10, origH + dy); break;
    case 'sw': el.x = origX + dx; el.width = Math.max(10, origW - dx); el.height = Math.max(10, origH + dy); break;
    case 'ne': el.y = origY + dy; el.width = Math.max(10, origW + dx); el.height = Math.max(10, origH - dy); break;
    case 'nw': el.x = origX + dx; el.y = origY + dy; el.width = Math.max(10, origW - dx); el.height = Math.max(10, origH - dy); break;
    case 'n': el.y = origY + dy; el.height = Math.max(10, origH - dy); break;
    case 's': el.height = Math.max(10, origH + dy); break;
    case 'w': el.x = origX + dx; el.width = Math.max(10, origW - dx); break;
    case 'e': el.width = Math.max(10, origW + dx); break;
  }

  renderCanvas();
  renderProperties();
}

function onResizeEnd(e) {
  if (resizeState) {
    saveHistory();
    resizeState = null;
  }
  document.removeEventListener('mousemove', onResizeMove);
  document.removeEventListener('mouseup', onResizeEnd);
}

// ============ 框选 ============
function onMultiSelectMove(e) {
  if (!multiSelectState) return;
  const coords = getCanvasCoords(e);
  multiSelectState.currentX = coords.x;
  multiSelectState.currentY = coords.y;

  const x = Math.min(multiSelectState.startX, coords.x);
  const y = Math.min(multiSelectState.startY, coords.y);
  const w = Math.abs(coords.x - multiSelectState.startX);
  const h = Math.abs(coords.y - multiSelectState.startY);

  AppState.selectBox = { x, y, w, h };

  // 选中框内的元素
  const page = getCurrentPage();
  if (page) {
    AppState.selectedIds = page.elements.filter(el => {
      if (!el.visible || el.locked) return false;
      return el.x < x + w && el.x + el.width > x && el.y < y + h && el.y + el.height > y;
    }).map(el => el.id);
  }

  renderCanvas();
  renderLayers();
}

function onMultiSelectEnd(e) {
  AppState.isMultiSelecting = false;
  AppState.selectBox = null;
  multiSelectState = null;
  document.removeEventListener('mousemove', onMultiSelectMove);
  document.removeEventListener('mouseup', onMultiSelectEnd);
  renderCanvas();
  renderProperties();
}

// ============ 绘图工具 ============
function startDrawing(coords, e) {
  const page = getCurrentPage();
  if (!page) return;

  switch(AppState.tool) {
    case 'rect':
    case 'circle': {
      drawState = {
        type: AppState.tool,
        startX: coords.x, startY: coords.y,
        el: createElement('svg-shape', {
          x: coords.x, y: coords.y,
          width: 0, height: 0,
          backgroundColor: 'transparent',
          borderWidth: 2,
          borderColor: AppState.drawingColor,
          borderRadius: AppState.tool === 'circle' ? 999 : 0,
        }),
      };
      addElementToPage(page.id, drawState.el);
      document.addEventListener('mousemove', onDrawShapeMove);
      document.addEventListener('mouseup', onDrawShapeEnd);
      break;
    }
    case 'line': {
      drawState = {
        type: 'line',
        startX: coords.x, startY: coords.y,
        points: [{x: coords.x, y: coords.y}, {x: coords.x, y: coords.y}],
      };
      document.addEventListener('mousemove', onDrawLineMove);
      document.addEventListener('mouseup', onDrawLineEnd);
      break;
    }
    case 'pen': {
      drawState = {
        type: 'pen',
        points: [{x: coords.x, y: coords.y}],
      };
      document.addEventListener('mousemove', onDrawPenMove);
      document.addEventListener('mouseup', onDrawPenEnd);
      break;
    }
  }
}

function onDrawShapeMove(e) {
  if (!drawState) return;
  const coords = getCanvasCoords(e);
  const el = drawState.el;
  el.x = Math.min(drawState.startX, coords.x);
  el.y = Math.min(drawState.startY, coords.y);
  el.width = Math.max(2, Math.abs(coords.x - drawState.startX));
  el.height = Math.max(2, Math.abs(coords.y - drawState.startY));
  renderCanvas();
}

function onDrawShapeEnd(e) {
  if (drawState && drawState.el) {
    if (drawState.el.width < 5 && drawState.el.height < 5) {
      // 太小，删除
      const page = getCurrentPage();
      if (page) page.elements = page.elements.filter(el => el.id !== drawState.el.id);
    } else {
      AppState.selectedIds = [drawState.el.id];
      saveHistory();
    }
  }
  drawState = null;
  document.removeEventListener('mousemove', onDrawShapeMove);
  document.removeEventListener('mouseup', onDrawShapeEnd);
  renderAll();
  AppState.tool = 'select';
  updateToolButtons();
}

function onDrawLineMove(e) {
  if (!drawState) return;
  const coords = getCanvasCoords(e);
  drawState.points[1] = {x: coords.x, y: coords.y};
}

function onDrawLineEnd(e) {
  if (drawState && drawState.points) {
  const [p1, p2] = drawState.points;
    const dx = p2.x - p1.x, dy = p2.y - p1.y;
    const length = Math.sqrt(dx*dx + dy*dy);
    if (length > 5) {
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      const el = createElement('svg-shape', {
        x: Math.min(p1.x, p2.x),
        y: Math.min(p1.y, p2.y) - AppState.drawingWidth/2,
        width: length,
        height: AppState.drawingWidth,
        backgroundColor: AppState.drawingColor,
        borderRadius: AppState.drawingWidth / 2,
        rotation: angle,
      });
      const page = getCurrentPage();
      if (page) {
        addElementToPage(page.id, el);
        AppState.selectedIds = [el.id];
        saveHistory();
      }
    }
  }
  drawState = null;
  document.removeEventListener('mousemove', onDrawLineMove);
  document.removeEventListener('mouseup', onDrawLineEnd);
  renderAll();
  AppState.tool = 'select';
  updateToolButtons();
}

function onDrawPenMove(e) {
  if (!drawState) return;
  const coords = getCanvasCoords(e);
  drawState.points.push({x: coords.x, y: coords.y});
  renderPenPreview();
}

function renderPenPreview() {
  if (!drawState || drawState.points.length < 2) return;
  const wrapper = document.getElementById('canvasWrapper');
  if (!wrapper) return;
  let existing = wrapper.querySelector('.pen-preview-svg');
  if (!existing) {
    existing = document.createElementNS('http://www.w3.org/2000/svg','svg');
    existing.classList.add('pen-preview-svg');
    existing.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9999;';
    wrapper.appendChild(existing);
  }
  let d = `M ${drawState.points[0].x} ${drawState.points[0].y}`;
  for (let i = 1; i < drawState.points.length; i++) {
    d += ` L ${drawState.points[i].x} ${drawState.points[i].y}`;
  }
  existing.innerHTML = `<path d="${d}" fill="none" stroke="${AppState.drawingColor}" stroke-width="${AppState.drawingWidth}" stroke-linecap="round" stroke-linejoin="round"/>`;
}

function onDrawPenEnd(e) {
  if (drawState && drawState.points.length > 2) {
    const bounds = getPointsBounds(drawState.points);
    // 创建SVG路径
    let d = `M ${drawState.points[0].x - bounds.minX} ${drawState.points[0].y - bounds.minY}`;
    for (let i = 1; i < drawState.points.length; i++) {
      d += ` L ${drawState.points[i].x - bounds.minX} ${drawState.points[i].y - bounds.minY}`;
    }
    const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${bounds.width}" height="${bounds.height}" viewBox="0 0 ${bounds.width} ${bounds.height}"><path d="${d}" fill="none" stroke="${AppState.drawingColor}" stroke-width="${AppState.drawingWidth}" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    
    const el = createElement('canvas-drawing', {
      x: bounds.minX, y: bounds.minY,
      width: bounds.width, height: bounds.height,
      backgroundColor: 'transparent',
    });
    el.drawingSvg = svgContent;
    
    const page = getCurrentPage();
    if (page) {
      addElementToPage(page.id, el);
      AppState.selectedIds = [el.id];
      saveHistory();
    }
  }
  // 清理预览
  const wrapper = document.getElementById('canvasWrapper');
  if (wrapper) {
    const preview = wrapper.querySelector('.pen-preview-svg');
    if (preview) preview.remove();
  }
  drawState = null;
  document.removeEventListener('mousemove', onDrawPenMove);
  document.removeEventListener('mouseup', onDrawPenEnd);
  renderAll();
  AppState.tool = 'select';
  updateToolButtons();
}

function getPointsBounds(points) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  points.forEach(p => { minX = Math.min(minX, p.x); minY = Math.min(minY, p.y); maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y); });
  return { minX, minY, maxX, maxY, width: maxX - minX, height: maxY - minY };
}

// ============ 画布平移和缩放 ============
function initCanvasPanZoom() {
  const viewport = document.getElementById('canvasViewport');
  if (!viewport) return;

  viewport.addEventListener('wheel', (e) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.05 : 0.05;
      AppState.zoom = clamp(AppState.zoom + delta, 0.1, 3);
      renderCanvas();
    } else {
      viewport.scrollBy(e.deltaX, e.deltaY);
    }
  }, { passive: false });

  // 中键/空格拖拽平移
  let isPanning = false;
  let panStart = { x: 0, y: 0 };

  viewport.addEventListener('mousedown', (e) => {
    if (e.button === 1 || (e.button === 0 && e.altKey)) { // 中键或Alt+左键
      e.preventDefault();
      isPanning = true;
      panStart = { x: e.clientX, y: e.clientY };
    }
  });

  document.addEventListener('mousemove', (e) => {
    if (!isPanning) return;
    const dx = e.clientX - panStart.x;
    const dy = e.clientY - panStart.y;
    viewport.scrollLeft -= dx;
    viewport.scrollTop -= dy;
    panStart = { x: e.clientX, y: e.clientY };
  });

  document.addEventListener('mouseup', (e) => {
    if (e.button === 1 || isPanning) isPanning = false;
  });
}

// ============ 工具按钮更新 ============
function updateToolButtons() {
  document.querySelectorAll('.tool-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tool === AppState.tool);
  });
  const canvasArea = document.querySelector('.canvas-area');
  if (canvasArea) {
    canvasArea.classList.toggle('drawing-mode', AppState.tool !== 'select');
  }
}

// ============ 双击编辑 ============
function initDoubleClickEdit() {
  document.addEventListener('dblclick', (e) => {
    const elTarget = e.target.closest('.canvas-element');
    if (!elTarget) return;
    const elId = elTarget.dataset.elId;
    const el = getElementById(elId);
    if (!el) return;
    if (el.locked) return;

    if (['text','heading','paragraph','button','link'].includes(el.type)) {
      startInlineEdit(el, elTarget);
    }
  });
}

function startInlineEdit(el, domEl) {
  const contentDiv = domEl.querySelector('div');
  if (!contentDiv) return;
  contentDiv.contentEditable = 'true';
  contentDiv.style.cursor = 'text';
  contentDiv.style.outline = '2px solid #4fc3f7';
  contentDiv.style.outlineOffset = '-2px';
  contentDiv.focus();

  // 选中全部文字
  const range = document.createRange();
  range.selectNodeContents(contentDiv);
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);

  const finish = () => {
    contentDiv.contentEditable = 'false';
    contentDiv.style.cursor = '';
    contentDiv.style.outline = '';
    contentDiv.style.outlineOffset = '';
    el.content = contentDiv.textContent;
    saveHistory();
    renderProperties();
  };

  contentDiv.addEventListener('blur', finish, { once: true });
  contentDiv.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { contentDiv.blur(); }
  });
}

// ============ 拖拽组件到画布 ============
function initDragFromPanel() {
  document.querySelectorAll('.component-item').forEach(item => {
    item.addEventListener('mousedown', (e) => {
      e.preventDefault();
      const type = item.dataset.type;
      
      // 创建幽灵元素
      const ghost = document.createElement('div');
      ghost.style.cssText = 'position:fixed;pointer-events:none;z-index:99999;padding:8px 16px;background:var(--accent-dim);border:1px solid var(--accent);border-radius:6px;color:var(--accent);font-size:12px;';
      ghost.textContent = item.querySelector('span')?.textContent || type;
      ghost.style.left = e.clientX + 10 + 'px';
      ghost.style.top = e.clientY + 10 + 'px';
      document.body.appendChild(ghost);

      const onMouseMove = (e) => {
        ghost.style.left = e.clientX + 10 + 'px';
        ghost.style.top = e.clientY + 10 + 'px';
      };

      const onMouseUp = (e) => {
        ghost.remove();
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);

        // 检查是否落在画布上
        const viewport = document.getElementById('canvasViewport');
        if (!viewport) return;
        const rect = viewport.getBoundingClientRect();
        if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) return;

        const coords = getCanvasCoords(e);
        const el = createElement(type, { x: coords.x - 60, y: coords.y - 20 });
        const page = getCurrentPage();
        if (page) {
          addElementToPage(page.id, el);
          AppState.selectedIds = [el.id];
          renderAll();
          showToast(`已添加 ${el.name}`);
        }
      };

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    });
  });
}

console.log('StarmoAI Design 交互系统已加载');
