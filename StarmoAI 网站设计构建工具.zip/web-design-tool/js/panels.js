// ============================================
// StarmoAI Design - 属性面板 / 预览 / 工作流 / 导航图 / 模板
// ============================================

// ============ 属性面板渲染 ============
function renderProperties() {
  const container = document.getElementById('propertiesContent');
  if (!container) return;

  if (AppState.selectedIds.length === 0) {
    container.innerHTML = renderPageProperties();
    bindPageProperties();
    return;
  }

  if (AppState.selectedIds.length === 1) {
    const el = getElementById(AppState.selectedIds[0]);
    if (!el) return;
    container.innerHTML = renderElementProperties(el);
    bindElementProperties(el);
    return;
  }

  // 多选
  container.innerHTML = renderMultiProperties();
}

function renderPageProperties() {
  const page = getCurrentPage();
  if (!page) return '<div class="empty-state"><p>无页面</p></div>';
  return `
    <div class="prop-group">
      <div class="prop-group-title">页面设置</div>
      <div class="prop-row">
        <span class="prop-label">名称</span>
        <input class="prop-input" id="propPageName" value="${escapeAttr(page.name)}">
      </div>
      <div class="prop-row">
        <span class="prop-label">宽度</span>
        <input class="prop-input-sm" id="propPageW" type="number" value="${page.width}">
        <span class="prop-label" style="width:auto;">高度</span>
        <input class="prop-input-sm" id="propPageH" type="number" value="${page.height}">
      </div>
      <div class="prop-row">
        <span class="prop-label">背景</span>
        <div class="prop-color-wrapper">
          <div class="prop-color-swatch" style="background:${page.backgroundColor}"><input type="color" id="propPageBg" value="${page.backgroundColor}"></div>
          <input class="prop-color-hex" id="propPageBgHex" value="${page.backgroundColor}">
        </div>
      </div>
    </div>
    <div class="prop-group">
      <div class="prop-group-title">页面链接</div>
      <div id="pageLinksList"></div>
      <div class="add-animation-btn" id="addPageLinkBtn" style="margin-top:6px;">+ 添加跳转链接</div>
    </div>
    <div class="prop-group">
      <div class="prop-group-title">SEO信息</div>
      <div class="prop-row">
        <span class="prop-label">标题</span>
        <input class="prop-input" id="propMetaTitle" value="${escapeAttr(page.meta.title)}" placeholder="页面标题">
      </div>
      <div class="prop-row">
        <span class="prop-label">描述</span>
        <input class="prop-input" id="propMetaDesc" value="${escapeAttr(page.meta.description)}" placeholder="页面描述">
      </div>
    </div>
  `;
}

function bindPageProperties() {
 const page = getCurrentPage(); if (!page) return;
  const $ = id => document.getElementById(id);

  const nameInput = $('propPageName');
  if (nameInput) nameInput.addEventListener('change', () => { page.name = nameInput.value; renderCanvasTabs(); renderNavTree(); });

  const wInput = $('propPageW');
  if (wInput) wInput.addEventListener('change', () => { page.width = parseInt(wInput.value) || 1440; saveHistory(); renderCanvas(); });

  const hInput = $('propPageH');
  if (hInput) hInput.addEventListener('change', () => { page.height = parseInt(hInput.value) || 900; saveHistory(); renderCanvas(); });

  const bgInput = $('propPageBg');
  if (bgInput) bgInput.addEventListener('input', () => {
    page.backgroundColor = bgInput.value;
    const hex = $('propPageBgHex'); if (hex) hex.value = bgInput.value;
    renderCanvas();
  });

  const bgHex = $('propPageBgHex');
  if (bgHex) bgHex.addEventListener('change', () => {
    page.backgroundColor = bgHex.value;
    const bg = $('propPageBg'); if (bg) bg.value = bgHex.value;
    renderCanvas();
  });

  const titleInput = $('propMetaTitle');
  if (titleInput) titleInput.addEventListener('change', () => { page.meta.title = titleInput.value; });
  const descInput = $('propMetaDesc');
  if (descInput) descInput.addEventListener('change', () => { page.meta.description = descInput.value; });

  // 页面链接
  renderPageLinks();
  const addLinkBtn = $('addPageLinkBtn');
  if (addLinkBtn) addLinkBtn.addEventListener('click', addPageLink);
}

function renderPageLinks() {
  const container = document.getElementById('pageLinksList');
  const page = getCurrentPage();
  if (!container || !page) return;

  if (page.links.length === 0) {
    container.innerHTML = '<div style="color:var(--text-muted);font-size:11px;padding:6px 0;">暂无跳转链接</div>';
    return;
  }

  container.innerHTML = page.links.map((link, i) => {
    const targetPage = AppState.pages.find(p => p.id === link.toPageId);
    return `<div class="animation-item">
      <span class="anim-name">→ ${targetPage ? targetPage.name : '未知'}</span>
      <div class="anim-actions">
        <span class="anim-action-btn" data-remove-link="${i}" title="删除">×</span>
      </div>
    </div>`;
  }).join('');

  container.querySelectorAll('[data-remove-link]').forEach(btn => {
    btn.addEventListener('click', () => {
      page.links.splice(parseInt(btn.dataset.removeLink), 1);
      saveHistory();
      renderPageLinks();
      renderNavTree();
    });
  });
}

function addPageLink() {
  const page = getCurrentPage();
  if (!page) return;
  const otherPages = AppState.pages.filter(p => p.id !== page.id);
  if (otherPages.length === 0) { showToast('没有其他页面可链接', 'error'); return; }
  // 简单：链接到第一个非当前页面
  const target = otherPages[0];
  page.links.push({ fromId: page.id, toPageId: target.id, label: `跳转到${target.name}` });
  saveHistory();
  renderPageLinks();
  renderNavTree();
  showToast(`已添加到 ${target.name} 的跳转`);
}

function renderElementProperties(el) {
  const s = el.styles;
  return `
    <div class="prop-group">
      <div class="prop-group-title">元素 <span style="color:var(--text-muted);font-weight:400;font-size:10px;">${el.name} (${el.type})</span></div>
      <div class="prop-row">
        <span class="prop-label">名称</span>
        <input class="prop-input" id="propName" value="${escapeAttr(el.name)}">
      </div>
    </div>

    ${['text','heading','paragraph','button','link','input'].includes(el.type) ? `
    <div class="prop-group">
      <div class="prop-group-title">内容</div>
      ${el.type === 'input' ? `
      <div class="prop-row">
        <span class="prop-label">占位符</span>
        <input class="prop-input" id="propPlaceholder" value="${escapeAttr(el.placeholder)}">
      </div>` : `
      <div class="prop-row">
        <textarea class="prop-textarea" id="propContent">${escapeAttr(el.content)}</textarea>
      </div>`}
    </div>` : ''}

    ${el.type === 'link' ? `
    <div class="prop-group">
      <div class="prop-group-title">链接</div>
      <div class="prop-row">
        <span class="prop-label">跳转页面</span>
        <select class="prop-select" id="propLinkToPage">
          <option value="">无</option>
          ${AppState.pages.map(p => `<option value="${p.id}" ${el.linkToPage === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
        </select>
      </div>
      <div class="prop-row">
        <span class="prop-label">URL</span>
        <input class="prop-input" id="propHref" value="${escapeAttr(el.href)}" placeholder="https://...">
      </div>
    </div>` : ''}

    <div class="prop-group">
      <div class="prop-group-title">位置与尺寸</div>
      <div class="prop-row">
        <span class="prop-label">X</span>
        <input class="prop-input-sm" id="propX" type="number" value="${Math.round(el.x)}">
        <span class="prop-label" style="width:auto;">Y</span>
        <input class="prop-input-sm" id="propY" type="number" value="${Math.round(el.y)}">
      </div>
      <div class="prop-row">
        <span class="prop-label">宽</span>
        <input class="prop-input-sm" id="propW" type="number" value="${Math.round(el.width)}">
        <span class="prop-label" style="width:auto;">高</span>
        <input class="prop-input-sm" id="propH" type="number" value="${Math.round(el.height)}">
      </div>
      <div class="prop-row">
        <span class="prop-label">旋转</span>
        <div class="prop-slider-row">
          <input class="prop-slider" id="propRotation" type="range" min="-180" max="180" value="${el.rotation}">
          <span style="font-size:11px;width:36px;text-align:right;">${el.rotation}°</span>
        </div>
      </div>
      <div class="prop-row">
        <span class="prop-label">透明度</span>
        <div class="prop-slider-row">
          <input class="prop-slider" id="propOpacity" type="range" min="0" max="100" value="${Math.round(el.opacity * 100)}">
          <span style="font-size:11px;width:36px;text-align:right;">${Math.round(el.opacity * 100)}%</span>
        </div>
      </div>
    </div>

    <div class="prop-group">
      <div class="prop-group-title">外观</div>
      <div class="prop-row">
        <span class="prop-label">背景色</span>
        <div class="prop-color-wrapper">
          <div class="prop-color-swatch" style="background:${s.backgroundColor}"><input type="color" id="propBgColor" value="${toHex(s.backgroundColor)}"></div>
          <input class="prop-color-hex" id="propBgColorHex" value="${s.backgroundColor}">
        </div>
      </div>
      <div class="prop-row">
        <span class="prop-label">文字色</span>
        <div class="prop-color-wrapper">
          <div class="prop-color-swatch" style="background:${s.color}"><input type="color" id="propTextColor" value="${toHex(s.color)}"></div>
          <input class="prop-color-hex" id="propTextColorHex" value="${s.color}">
        </div>
      </div>
      <div class="prop-row">
        <span class="prop-label">字体</span>
        <select class="prop-select" id="propFontFamily">
          ${['sans-serif','serif','monospace','cursive'].map(f => `<option value="${f}" ${s.fontFamily===f?'selected':''}>${f}</option>`).join('')}
        </select>
      </div>
      <div class="prop-row">
        <span class="prop-label">字号</span>
        <input class="prop-input-sm" id="propFontSize" type="number" value="${s.fontSize}" min="8" max="200">
        <span class="prop-label" style="width:auto;">字重</span>
        <select class="prop-select" id="propFontWeight" style="width:70px;">
          ${['normal','bold','100','200','300','400','500','600','700','800','900'].map(w => `<option value="${w}" ${s.fontWeight===w?'selected':''}>${w}</option>`).join('')}
        </select>
      </div>
      <div class="prop-row">
        <span class="prop-label">对齐</span>
        <div class="toolbar-btn-group" style="flex:1;">
          <button class="toolbar-btn align-btn ${s.textAlign==='left'?'active':''}" data-align="left">⫷</button>
          <button class="toolbar-btn align-btn ${s.textAlign==='center'?'active':''}" data-align="center">⫿</button>
          <button class="toolbar-btn align-btn ${s.textAlign==='right'?'active':''}" data-align="right">⫸</button>
        </div>
      </div>
      <div class="prop-row">
        <span class="prop-label">行高</span>
        <input class="prop-input-sm" id="propLineHeight" type="number" step="0.1" value="${s.lineHeight}">
        <span class="prop-label" style="width:auto;">间距</span>
        <input class="prop-input-sm" id="propLetterSpacing" type="number" value="${s.letterSpacing}">
      </div>
    </div>

    <div class="prop-group">
      <div class="prop-group-title">边框与圆角</div>
      <div class="prop-row">
        <span class="prop-label">圆角</span>
        <div class="prop-slider-row">
          <input class="prop-slider" id="propBorderRadius" type="range" min="0" max="200" value="${s.borderRadius}">
          <span style="font-size:11px;width:36px;text-align:right;">${s.borderRadius}px</span>
        </div>
      </div>
      <div class="prop-row">
        <span class="prop-label">边框宽</span>
        <input class="prop-input-sm" id="propBorderWidth" type="number" value="${s.borderWidth}" min="0" max="50">
        <span class="prop-label" style="width:auto;">边框色</span>
        <div class="prop-color-swatch" style="background:${s.borderColor};width:28px;height:28px;border-radius:4px;border:2px solid var(--border);flex-shrink:0;"><input type="color" id="propBorderColor" value="${toHex(s.borderColor)}"></div>
      </div>
      <div class="prop-row">
        <span class="prop-label">边框样式</span>
        <select class="prop-select" id="propBorderStyle">
          ${['solid','dashed','dotted','double','none'].map(b => `<option value="${b}" ${s.borderStyle===b?'selected':''}>${b}</option>`).join('')}
        </select>
      </div>
      <div class="prop-row">
        <span class="prop-label">阴影</span>
        <input class="prop-input" id="propBoxShadow" value="${escapeAttr(s.boxShadow)}" placeholder="0 2px 8px rgba(0,0,0,0.1)">
      </div>
    </div>

    <div class="prop-group">
      <div class="prop-group-title">内间距</div>
      <div class="prop-row">
        <span class="prop-label">Padding</span>
        <input class="prop-input-sm" id="propPadding" type="number" value="${s.padding}" min="0">
      </div>
    </div>

    <div class="prop-group">
      <div class="prop-group-title">布局</div>
      <div class="prop-row">
        <span class="prop-label">显示</span>
        <select class="prop-select" id="propDisplay">
          <option value="block" ${s.display==='block'?'selected':''}>Block</option>
          <option value="flex" ${s.display==='flex'?'selected':''}>Flex</option>
          <option value="grid" ${s.display==='grid'?'selected':''}>Grid</option>
          <option value="inline-flex" ${s.display==='inline-flex'?'selected':''}>Inline Flex</option>
        </select>
      </div>
      ${s.display === 'flex' || s.display === 'inline-flex' ? `
      <div class="prop-row">
        <span class="prop-label">方向</span>
        <select class="prop-select" id="propFlexDir">
          <option value="row" ${s.flexDirection==='row'?'selected':''}>水平</option>
          <option value="column" ${s.flexDirection==='column'?'selected':''}>垂直</option>
        </select>
      </div>
      <div class="prop-row">
        <span class="prop-label">主轴对齐</span>
        <select class="prop-select" id="propJustify">
          ${['flex-start','center','flex-end','space-between','space-around','space-evenly'].map(j => `<option value="${j}" ${s.justifyContent===j?'selected':''}>${j}</option>`).join('')}
        </select>
      </div>
      <div class="prop-row">
        <span class="prop-label">交叉轴</span>
        <select class="prop-select" id="propAlignItems">
          ${['flex-start','center','flex-end','stretch','baseline'].map(a => `<option value="${a}" ${s.alignItems===a?'selected':''}>${a}</option>`).join('')}
        </select>
      </div>
      <div class="prop-row">
        <span class="prop-label">间距</span>
        <input class="prop-input-sm" id="propGap" type="number" value="${s.gap}" min="0">
      </div>
      ` : ''}
    </div>

    <div class="prop-group">
      <div class="prop-group-title">动画</div>
      <div class="animation-list" id="animationList"></div>
      <div class="add-animation-btn" id="addAnimBtn" style="margin-top:6px;">+ 添加动画</div>
    </div>
  `;
}

function bindElementProperties(el) {
  const $ = id => document.getElementById(id);
  const s = el.styles;

  const bind = (id, prop, isStyle = true, transform) => {
    const input = $(id);
    if (!input) return;
    input.addEventListener('change', () => {
      const val = transform ? transform(input.value) : input.value;
      if (isStyle) s[prop] = val; else el[prop] = val;
      saveHistory(); renderCanvas(); renderProperties();
    });
    // 实时预览
    if (input.type === 'range' || input.type === 'color') {
      input.addEventListener('input', () => {
        const val = transform ? transform(input.value) : input.value;
        if (isStyle) s[prop] = val; else el[prop] = val;
        renderCanvas();
      });
    }
  };

  bind('propName', 'name', false);
  bind('propContent', 'content', false);
  bind('propPlaceholder', 'placeholder', false);
  bind('propX', 'x', false, v => parseInt(v) || 0);
  bind('propY', 'y', false, v => parseInt(v) || 0);
  bind('propW', 'width', false, v => Math.max(10, parseInt(v) || 10));
  bind('propH', 'height', false, v => Math.max(10, parseInt(v) || 10));
  bind('propRotation', 'rotation', false, v => parseInt(v));
  bind('propOpacity', 'opacity', false, v => parseInt(v) / 100);
  bind('propBgColor', 'backgroundColor');
  bind('propTextColor', 'color');
  bind('propFontFamily', 'fontFamily');
  bind('propFontSize', 'fontSize', true, v => parseInt(v) || 14);
  bind('propFontWeight', 'fontWeight');
  bind('propLineHeight', 'lineHeight', true, parseFloat);
  bind('propLetterSpacing', 'letterSpacing', true, v => parseInt(v) || 0);
  bind('propBorderRadius', 'borderRadius', true, v => parseInt(v));
  bind('propBorderWidth', 'borderWidth', true, v => parseInt(v) || 0);
  bind('propBorderColor', 'borderColor');
  bind('propBorderStyle', 'borderStyle');
  bind('propBoxShadow', 'boxShadow');
  bind('propPadding', 'padding', true, v => parseInt(v) || 0);
  bind('propDisplay', 'display');
  bind('propFlexDir', 'flexDirection');
  bind('propJustify', 'justifyContent');
  bind('propAlignItems', 'alignItems');
  bind('propGap', 'gap', true, v => parseInt(v) || 0);

  // 颜色hex输入同步
  const bgHex = $('propBgColorHex');
  if (bgHex) bgHex.addEventListener('change', () => { s.backgroundColor = bgHex.value; renderCanvas(); });
  const txtHex = $('propTextColorHex');
  if (txtHex) txtHex.addEventListener('change', () => { s.color = txtHex.value; renderCanvas(); });

  // 对齐按钮
  document.querySelectorAll('.align-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      s.textAlign = btn.dataset.align;
      saveHistory(); renderCanvas(); renderProperties();
    });
  });

  // 链接跳转
  const linkToPage = $('propLinkToPage');
  if (linkToPage) linkToPage.addEventListener('change', () => { el.linkToPage = linkToPage.value; saveHistory(); });
  const hrefInput = $('propHref');
  if (hrefInput) hrefInput.addEventListener('change', () => { el.href = hrefInput.value; saveHistory(); });

  // 动画
  renderAnimations(el);
  const addAnimBtn = $('addAnimBtn');
  if (addAnimBtn) addAnimBtn.addEventListener('click', () => addAnimation(el));
}

function renderAnimations(el) {
  const container = document.getElementById('animationList');
  if (!container) return;
  if (!el.animations || el.animations.length === 0) {
    container.innerHTML = '<div style="color:var(--text-muted);font-size:11px;padding:4px 0;">无动画</div>';
    return;
  }
  container.innerHTML = el.animations.map((anim, i) => `
    <div class="animation-item">
      <span class="anim-name">${anim.type} ${anim.delay}s</span>
      <div class="anim-actions">
        <span class="anim-action-btn" data-remove-anim="${i}" title="删除">×</span>
      </div>
    </div>
  `).join('');
  container.querySelectorAll('[data-remove-anim]').forEach(btn => {
    btn.addEventListener('click', () => {
      el.animations.splice(parseInt(btn.dataset.removeAnim), 1);
      saveHistory(); renderAnimations(el);
    });
  });
}

function addAnimation(el) {
  const types = ['fadeIn','slideInLeft','slideInRight','slideInUp','slideInDown','zoomIn','bounceIn','rotateIn','pulse','shake'];
  const type = types[Math.floor(Math.random() * types.length)];
  el.animations.push({ type, duration: 0.6, delay: 0, easing: 'ease' });
  saveHistory(); renderAnimations(el);
  showToast(`已添加 ${type} 动画`);
}

function renderMultiProperties() {
  return `
    <div class="prop-group">
      <div class="prop-group-title">多选 (${AppState.selectedIds.length}个元素)</div>
    </div>
    <div class="prop-group">
      <div class="prop-group-title">对齐</div>
      <div style="display:flex;flex-wrap:wrap;gap:4px;">
        ${[['left','左对齐'],['right','右对齐'],['top','上对齐'],['bottom','下对齐'],['centerH','水平居中'],['centerV','垂直居中'],['distributeH','水平分布'],['distributeV','垂直分布']].map(([k,v]) =>
          `<button class="toolbar-btn multi-align-btn" style="background:var(--bg-input);border:1px solid var(--border);" data-align-action="${k}" title="${v}">${v}</button>`
        ).join('')}
      </div>
    </div>
    <div class="prop-group">
      <div class="prop-group-title">操作</div>
      <button class="add-animation-btn" id="multiDuplicate">复制选中</button>
      <button class="add-animation-btn" id="multiDelete" style="margin-top:4px;color:var(--accent);">删除选中</button>
    </div>
  `;
}

function bindMultiProperties() {
  document.querySelectorAll('[data-align-action]').forEach(btn => {
    btn.addEventListener('click', () => alignElements(btn.dataset.alignAction));
  });
  const dupBtn = document.getElementById('multiDuplicate');
  if (dupBtn) dupBtn.addEventListener('click', () => { duplicateElements(AppState.selectedIds); });
  const delBtn = document.getElementById('multiDelete');
  if (delBtn) delBtn.addEventListener('click', () => { deleteElements(AppState.selectedIds); });
}

// 属性面板切换时绑定事件
const origRenderProperties = renderProperties;
renderProperties = function() {
  origRenderProperties();
  if (AppState.selectedIds.length > 1) bindMultiProperties();
};

// ============ 工具函数 ============
function escapeAttr(str) { return String(str).replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

function toHex(color) {
  if (!color) return '#000000';
  if (color.startsWith('#') && color.length === 7) return color;
  if (color === 'transparent') return '#000000';
  // 简单转换
  const temp = document.createElement('div');
  temp.style.color = color;
  document.body.appendChild(temp);
  const computed = getComputedStyle(temp).color;
  document.body.removeChild(temp);
  const match = computed.match(/\d+/g);
  if (match && match.length >= 3) {
    return '#' + match.slice(0,3).map(n => parseInt(n).toString(16).padStart(2,'0')).join('');
  }
  return '#000000';
}

// ============ 预览系统 ============
function openPreview(device = 'desktop') {
  const overlay = document.querySelector('.preview-overlay');
  if (!overlay) return;
  overlay.classList.add('active');

  const content = document.getElementById('previewContent');
  if (!content) return;

  const widths = { desktop: 1440, tablet: 768, mobile: 375 };
  content.style.width = (widths[device] || 1440) + 'px';

  renderPreviewContent(content, device);

  // 更新设备按钮状态
  overlay.querySelectorAll('.preview-device-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.device === device);
  });
}

function renderPreviewContent(container, device) {
  // 收集所有页面的HTML
  let allHtml = '';
  AppState.pages.forEach(page => {
    const sorted = [...page.elements].sort((a,b) => (a.zIndex||0) - (b.zIndex||0));
    let pageHtml = `<div id="preview-page-${page.id}" class="preview-page" style="display:${page.id === AppState.currentPageId ? 'block' : 'none'};width:${page.width}px;min-height:${page.height}px;background:${page.backgroundColor};position:relative;overflow:hidden;">`;

    sorted.forEach(el => {
      if (!el.visible) return;
      const s = el.styles;
      let style = `position:absolute;left:${el.x}px;top:${el.y}px;width:${el.width}px;height:${el.height}px;background-color:${s.backgroundColor};color:${s.color};font-size:${s.fontSize}px;font-weight:${s.fontWeight};font-family:${s.fontFamily};text-align:${s.textAlign};border-radius:${s.borderRadius}px;border:${s.borderWidth}px ${s.borderStyle} ${s.borderColor};box-shadow:${s.boxShadow};padding:${s.padding}px;overflow:${s.overflow};line-height:${s.lineHeight};letter-spacing:${s.letterSpacing}px;opacity:${el.opacity};`;

      // 添加动画CSS
      let animCSS = '';
      if (el.animations && el.animations.length > 0) {
        el.animations.forEach((anim, i) => {
          const animName = `wc-${anim.type}`;
          animCSS += `animation: ${animName} ${anim.duration}s ${anim.easing} ${anim.delay}s both;`;
        });
      }
      style += animCSS;

      if (s.display === 'flex' || s.display === 'inline-flex') {
        style += `display:flex;flex-direction:${s.flexDirection};justify-content:${s.justifyContent};align-items:${s.alignItems};gap:${s.gap}px;`;
      }

      if (el.type === 'button' && el.linkToPage) {
        style += 'cursor:pointer;';
        pageHtml += `<div style="${style}" data-link-page="${el.linkToPage}">${escapeHtml(el.content || '按钮')}</div>`;
      } else if (el.type === 'link' && el.linkToPage) {
        pageHtml += `<div style="${style}color:#4fc3f7;text-decoration:underline;cursor:pointer;" data-link-page="${el.linkToPage}">${escapeHtml(el.content || '链接')}</div>`;
      } else {
        // 复用渲染器的预览内容
        let inner = '';
        switch(el.type) {
          case 'text': case 'heading': case 'paragraph': inner = escapeHtml(el.content); break;
          case 'button': inner = escapeHtml(el.content || '按钮'); break;
          case 'nav': inner = renderNavPreview(el); break;
          case 'list': inner = renderListPreview(el); break;
          case 'form': inner = '表单区域'; break;
          case 'table': inner = renderTablePreview(el); break;
          case 'canvas-drawing': inner = el.drawingSvg || ''; break;
          case 'hero': inner = `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:8px;text-align:center;"><div style="font-size:24px;font-weight:700;">大标题</div><div style="font-size:13px;color:#888;">副标题</div><div style="padding:8px 24px;background:#e94560;color:#fff;border-radius:6px;">立即开始</div></div>`; break;
          case 'header': inner = renderHeaderPreview(el); break;
          case 'footer': inner = `<div style="display:flex;align-items:center;justify-content:space-between;height:100%;padding:0 20px;color:#888;"><span>© 2026 MySite</span><div style="display:flex;gap:16px;"><span>关于</span><span>联系</span><span>隐私</span></div></div>`; break;
          case 'card': inner = `<div style="padding:12px;"><div style="height:8px;width:60%;background:#e0e0e0;border-radius:4px;margin-bottom:6px;"></div><div style="height:6px;width:90%;background:#f0f0f0;border-radius:3px;margin-bottom:4px;"></div><div style="height:6px;width:75%;background:#f0f0f0;border-radius:3px;"></div></div>`; break;
          case 'divider': style += 'height:2px;'; break;
          default: break;
        }
        pageHtml += `<div style="${style}">${inner}</div>`;
      }
    });

    pageHtml += '</div>';
    allHtml += pageHtml;
  });

  // 动画关键帧
  const animKeyframes = `
    <style>
      @keyframes wc-fadeIn { from { opacity:0; } to { opacity:1; } }
      @keyframes wc-slideInLeft { from { transform:translateX(-50px); opacity:0; } to { transform:translateX(0); opacity:1; } }
      @keyframes wc-slideInRight { from { transform:translateX(50px); opacity:0; } to { transform:translateX(0); opacity:1; } }
      @keyframes wc-slideInUp { from { transform:translateY(50px); opacity:0; } to { transform:translateY(0); opacity:1; } }
      @keyframes wc-slideInDown { from { transform:translateY(-50px); opacity:0; } to { transform:translateY(0); opacity:1; } }
      @keyframes wc-zoomIn { from { transform:scale(0.5); opacity:0; } to { transform:scale(1); opacity:1; } }
      @keyframes wc-bounceIn { 0% { transform:scale(0.3); opacity:0; } 50% { transform:scale(1.05); } 70% { transform:scale(0.9); } 100% { transform:scale(1); opacity:1; } }
      @keyframes wc-rotateIn { from { transform:rotate(-200deg); opacity:0; } to { transform:rotate(0); opacity:1; } }
      @keyframes wc-pulse { 0%,100% { transform:scale(1); } 50% { transform:scale(1.05); } }
      @keyframes wc-shake { 0%,100% { transform:translateX(0); } 10%,30%,50%,70%,90% { transform:translateX(-5px); } 20%,40%,60%,80% { transform:translateX(5px); } }
    </style>
  `;

  container.innerHTML = animKeyframes + allHtml;

  // 绑定页面跳转
  container.querySelectorAll('[data-link-page]').forEach(el => {
    el.addEventListener('click', () => {
 const targetId = el.dataset.linkPage;
      container.querySelectorAll('.preview-page').forEach(p => p.style.display = 'none');
      const target = document.getElementById(`preview-page-${targetId}`);
      if (target) target.style.display = 'block';
    });
  });
}

function closePreview() {
  const overlay = document.querySelector('.preview-overlay');
  if (overlay) overlay.classList.remove('active');
}

console.log('StarmoAI Design 面板系统已加载');