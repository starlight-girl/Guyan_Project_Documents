// ============================================
// StarmoAI Design - 渲染引擎
// ============================================

function renderAll() {
  renderCanvasTabs();
  renderCanvas();
  renderNavTree();
  renderLayers();
  renderProperties();
}

// ============ 画布标签页 ============
function renderCanvasTabs() {
  const bar = document.getElementById('canvasTabsBar');
  if (!bar) return;
  bar.innerHTML = '';
  AppState.pages.forEach(page => {
    const tab = document.createElement('div');
    tab.className = `canvas-tab${page.id === AppState.currentPageId ? ' active' : ''}`;
    tab.innerHTML = `
      <span>${page.name}</span>
      ${AppState.pages.length > 1 ? '<span class="tab-close">×</span>' : ''}
    `;
    tab.addEventListener('click', (e) => {
      if (e.target.classList.contains('tab-close')) {
        deletePage(page.id);
        renderAll();
        return;
      }
      switchPage(page.id);
    });
    bar.appendChild(tab);
  });
  // 添加页面按钮
  const addBtn = document.createElement('div');
  addBtn.className = 'canvas-tab-add';
  addBtn.textContent = '+';
  addBtn.addEventListener('click', () => {
    const name = `页面 ${AppState.pages.length + 1}`;
    createPage(name);
    switchPage(AppState.pages[AppState.pages.length-1].id);
    renderAll();
    showToast('已创建新页面');
  });
  bar.appendChild(addBtn);
}

// ============ 画布渲染 ============
function renderCanvas() {
  const page = getCurrentPage();
  const viewport = document.getElementById('canvasViewport');
  const wrapper = document.getElementById('canvasWrapper');
  if (!viewport || !wrapper || !page) return;

  // 计算页面居中位置
  const vpW = viewport.clientWidth;
  const vpH = viewport.clientHeight;
  const padX = 80, padY = 60;
  const pageW = page.width * AppState.zoom;
  const pageH = page.height * AppState.zoom;
  const left = Math.max(padX, (vpW - pageW) / 2);
  const top = Math.max(padY, (vpH - pageH) / 2);

  wrapper.style.transform = `translate(${left}px, ${top}px) scale(${AppState.zoom})`;

  // 渲染页面
  let html = `<div class="canvas-page" data-page-id="${page.id}" style="width:${page.width}px;height:${page.height}px;background:${page.backgroundColor}">`;
  html += '<div class="canvas-page-inner">';

  // 按zIndex排序渲染元素
  const sorted = [...page.elements].sort((a,b) => (a.zIndex||0) - (b.zIndex||0));
  sorted.forEach(el => {
    if (!el.visible) return;
    html += renderElement(el);
  });

  html += '</div></div>';

  // 辅助线
  AppState.guides.forEach(g => {
    if (g.type === 'h') {
      html += `<div class="guide-line horizontal" style="top:${g.pos}px;"></div>`;
    } else {
      html += `<div class="guide-line vertical" style="left:${g.pos}px;"></div>`;
    }
  });

  // 选择框
  if (AppState.isMultiSelecting && AppState.selectBox) {
    const sb = AppState.selectBox;
    html += `<div class="selection-box" style="left:${sb.x}px;top:${sb.y}px;width:${sb.w}px;height:${sb.h}px;"></div>`;
  }

  wrapper.innerHTML = html;

  // 绑定画布事件
  bindCanvasEvents();

  // 更新缩放显示
  const zoomDisp = document.getElementById('zoomDisplay');
  if (zoomDisp) zoomDisp.textContent = Math.round(AppState.zoom * 100) + '%';
}

// ============ 单个元素渲染 ============
function renderElement(el) {
  const s = el.styles;
  const isSelected = AppState.selectedIds.includes(el.id);
  const isMulti = AppState.selectedIds.length > 1 && isSelected;

  let style = `
    position:absolute;
    left:${el.x}px;top:${el.y}px;
    width:${el.width}px;height:${el.height}px;
    opacity:${el.opacity};
    transform:rotate(${el.rotation}deg);
    background-color:${s.backgroundColor};
    color:${s.color};
    font-size:${s.fontSize}px;
    font-weight:${s.fontWeight};
    font-family:${s.fontFamily};
    text-align:${s.textAlign};
    border-radius:${s.borderRadius}px;
    border:${s.borderWidth}px ${s.borderStyle} ${s.borderColor};
    box-shadow:${s.boxShadow};
    padding:${s.padding}px;
    overflow:${s.overflow};
    line-height:${s.lineHeight};
    letter-spacing:${s.letterSpacing}px;
    display:${s.display};
    flex-direction:${s.flexDirection};
    justify-content:${s.justifyContent};
    align-items:${s.alignItems};
    gap:${s.gap}px;
    cursor:${el.locked ? 'not-allowed' : 'move'};
    user-select:none;
  `;

  if (s.backgroundImage) {
    style += `background-image:url('${s.backgroundImage}');background-size:${s.backgroundSize};background-position:${s.backgroundPosition};`;
  }

  let classes = 'canvas-element';
  if (isSelected && AppState.selectedIds.length === 1) classes += ' selected';
  if (isMulti) classes += ' multi-selected';

  let inner = '';

  switch(el.type) {
    case 'box':
      break;
    case 'text':
    case 'heading':
    case 'paragraph':
      inner = `<div style="width:100%;height:100%;overflow:hidden;word-break:break-word;">${escapeHtml(el.content)}</div>`;
      break;
    case 'button':
      inner = `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-weight:500;">${escapeHtml(el.content || '按钮')}</div>`;
      break;
    case 'input':
      inner = `<div style="display:flex;align-items:center;padding:0 10px;width:100%;height:100%;color:#999;font-size:${s.fontSize}px;">${escapeHtml(el.placeholder || '请输入...')}</div>`;
      break;
    case 'image':
      if (s.backgroundImage) {
        inner = '';
      } else {
        inner = `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;color:#bbb;font-size:12px;flex-direction:column;gap:4px;"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg><span>图片占位</span></div>`;
      }
      break;
    case 'nav':
      inner = renderNavPreview(el);
      break;
    case 'container':
      inner = `<div style="width:100%;height:100%;border:1px dashed rgba(150,150,200,0.4);display:flex;align-items:center;justify-content:center;color:#bbb;font-size:11px;">容器</div>`;
      break;
    case 'link':
      inner = `<div style="color:#4fc3f7;text-decoration:underline;display:flex;align-items:center;height:100%;padding:0 4px;">${escapeHtml(el.content || '链接文本')}</div>`;
      break;
    case 'list':
      inner = renderListPreview(el);
      break;
    case 'form':
      inner = `<div style="padding:10px;display:flex;flex-direction:column;gap:8px;"><div style="height:28px;background:#f5f5f5;border:1px solid #ddd;border-radius:4px;"></div><div style="height:28px;background:#f5f5f5;border:1px solid #ddd;border-radius:4px;"></div><div style="height:32px;background:#e94560;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;">提交</div></div>`;
      break;
    case 'table':
      inner = renderTablePreview(el);
      break;
    case 'svg-shape':
      inner = ''; // 由背景色/边框表示
      break;
    case 'canvas-drawing':
      inner = el.drawingSvg || '';
      break;
    case 'divider':
      el.height = 2;
      style += 'height:2px;';
      break;
    case 'icon':
      inner = `<div style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;"><svg width="${Math.min(el.width,el.height)*0.6}" height="${Math.min(el.width,el.height)*0.6}" viewBox="0 0 24 24" fill="none" stroke="${s.color}" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg></div>`;
      break;
    case 'card':
      inner = `<div style="padding:12px;display:flex;flex-direction:column;gap:6px;"><div style="height:8px;width:60%;background:#e0e0e0;border-radius:4px;"></div><div style="height:6px;width:90%;background:#f0f0f0;border-radius:3px;"></div><div style="height:6px;width:75%;background:#f0f0f0;border-radius:3px;"></div></div>`;
      break;
    case 'hero':
      inner = `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:8px;text-align:center;"><div style="font-size:24px;font-weight:700;color:#333;">大标题</div><div style="font-size:13px;color:#888;max-width:60%;">这里是副标题描述文字</div><div style="margin-top:4px;padding:8px 24px;background:#e94560;color:#fff;border-radius:6px;font-size:13px;">立即开始</div></div>`;
      break;
    case 'header':
      inner = renderHeaderPreview(el);
      break;
    case 'footer':
      inner = `<div style="display:flex;align-items:center;justify-content:space-between;height:100%;padding:0 20px;color:#888;font-size:12px;"><span>© 2026 MySite</span><div style="display:flex;gap:16px;"><span>关于</span><span>联系</span><span>隐私</span></div></div>`;
      break;
    case 'section':
      inner = `<div style="width:100%;height:100%;border:1px dashed rgba(150,150,200,0.3);display:flex;align-items:center;justify-content:center;color:#ccc;font-size:11px;">区块</div>`;
      break;
  }

  let result = `<div class="${classes}" data-el-id="${el.id}" style="${style}">${inner}</div>`;

  // 选中时显示调整手柄
  if (isSelected && AppState.selectedIds.length === 1 && !el.locked) {
    result += `
      <div class="resize-handle nw" data-handle="nw" data-el-id="${el.id}"></div>
      <div class="resize-handle ne" data-handle="ne" data-el-id="${el.id}"></div>
      <div class="resize-handle sw" data-handle="sw" data-el-id="${el.id}"></div>
      <div class="resize-handle se" data-handle="se" data-el-id="${el.id}"></div>
      <div class="resize-handle n" data-handle="n" data-el-id="${el.id}"></div>
      <div class="resize-handle s" data-handle="s" data-el-id="${el.id}"></div>
      <div class="resize-handle w" data-handle="w" data-el-id="${el.id}"></div>
      <div class="resize-handle e" data-handle="e" data-el-id="${el.id}"></div>
    `;
  }

  return result;
}

function renderNavPreview(el) {
  return `<div style="display:flex;align-items:center;height:100%;padding:0 16px;gap:24px;"><span style="font-weight:600;font-size:15px;">Logo</span><div style="display:flex;gap:16px;font-size:13px;"><span>首页</span><span>产品</span><span>关于</span><span>联系</span></div></div>`;
}

function renderListPreview(el) {
  return `<div style="padding:8px 12px;display:flex;flex-direction:column;gap:6px;font-size:13px;"><div>• 列表项 1</div><div>• 列表项 2</div><div>• 列表项 3</div></div>`;
}

function renderTablePreview(el) {
  return `<div style="width:100%;height:100%;overflow:hidden;"><table style="width:100%;border-collapse:collapse;font-size:12px;"><tr style="background:#f5f5f5;"><td style="border:1px solid #ddd;padding:6px;">表头1</td><td style="border:1px solid #ddd;padding:6px;">表头2</td><td style="border:1px solid #ddd;padding:6px;">表头3</td></tr><tr><td style="border:1px solid #ddd;padding:6px;">数据</td><td style="border:1px solid #ddd;padding:6px;">数据</td><td style="border:1px solid #ddd;padding:6px;">数据</td></tr></table></div>`;
}

function renderHeaderPreview(el) {
  return `<div style="display:flex;align-items:center;height:100%;padding:0 20px;justify-content:space-between;border-bottom:1px solid #eee;"><div style="font-weight:700;font-size:16px;">MyBrand</div><div style="display:flex;gap:20px;font-size:13px;"><span>首页</span><span>功能</span><span>定价</span><span>文档</span><button style="padding:6px 16px;background:#e94560;color:#fff;border-radius:6px;font-size:12px;">登录</button></div></div>`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ============ 图层列表渲染 ============
function renderLayers() {
  const container = document.getElementById('layersList');
  if (!container) return;
  const page = getCurrentPage();
  if (!page) { container.innerHTML = '<div class="empty-state"><p>无页面</p></div>'; return; }

  if (page.elements.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>画布上没有元素</p><p>从左侧拖入组件开始设计</p></div>';
    return;
  }

  // 倒序显示（最上层在列表最上面）
  const reversed = [...page.elements].reverse();
  container.innerHTML = reversed.map(el => {
    const isActive = AppState.selectedIds.includes(el.id);
    return `
      <div class="layer-item${isActive ? ' active' : ''}" data-layer-id="${el.id}">
        <span class="layer-visibility ${el.visible ? 'visible' : ''}" data-vis-id="${el.id}">👁</span>
        <span class="layer-name">${el.name}</span>
        <div class="layer-actions">
          <span class="layer-action-btn" data-lock-id="${el.id}">${el.locked ? '🔒' : '🔓'}</span>
        </div>
      </div>
    `;
  }).join('');

  // 绑定事件
  container.querySelectorAll('.layer-item').forEach(item => {
    item.addEventListener('click', (e) => {
 if (e.target.closest('.layer-visibility') || e.target.closest('.layer-action-btn')) return;
      const id = item.dataset.layerId;
      AppState.selectedIds = [id];
      renderCanvas();
      renderLayers();
      renderProperties();
    });
  });

  container.querySelectorAll('.layer-visibility').forEach(btn => {
    btn.addEventListener('click', () => {
      const el = getElementById(btn.dataset.visId);
      if (el) { el.visible = !el.visible; renderCanvas(); renderLayers(); }
    });
  });

  container.querySelectorAll('[data-lock-id]').forEach(btn => {
    btn.addEventListener('click', () => {
      const el = getElementById(btn.dataset.lockId);
      if (el) { el.locked = !el.locked; renderCanvas(); renderLayers(); }
    });
  });
}

// ============ 页面导航树渲染 ============
function renderNavTree() {
  const container = document.getElementById('navTreeContainer');
  if (!container) return;
  if (AppState.pages.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>暂无页面</p></div>';
    return;
  }

  const root = AppState.pages[0];
  let html = renderTreeNode(root, 0);
  html += `<div class="tree-add-btn" id="addPageBtn">+ 添加页面</div>`;
  container.innerHTML = html;

  // 绑定事件
  container.querySelectorAll('.tree-node').forEach(node => {
    node.addEventListener('click', (e) => {
      if (e.target.closest('.node-action-btn')) return;
      const pageId = node.dataset.pageId;
      switchPage(pageId);
    });
  });

  container.querySelectorAll('[data-delete-page]').forEach(btn => {
    btn.addEventListener('click', () => {
      deletePage(btn.dataset.deletePage);
      renderAll();
    });
  });

  const addBtn = document.getElementById('addPageBtn');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const name = `页面 ${AppState.pages.length + 1}`;
      createPage(name);
      switchPage(AppState.pages[AppState.pages.length-1].id);
      renderAll();
      showToast('已创建新页面');
    });
  }
}

function renderTreeNode(page, depth) {
  const isActive = page.id === AppState.currentPageId;
  const hasLinks = AppState.pages.some(p => p.links.some(l => l.toPageId === page.id));
  const linkCount = page.links.length;
  const children = AppState.pages.filter(p => p.id !== page.id && page.links.some(l => l.toPageId === p.id));

  let html = `<div class="tree-node${isActive ? ' active' : ''}" data-page-id="${page.id}" style="padding-left:${8 + depth * 20}px;">`;
  html += `<svg class="node-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`;
  html += `<span class="node-label">${page.name}</span>`;
  html += `<div class="node-actions">`;
  if (AppState.pages.length > 1) {
    html += `<span class="node-action-btn" data-delete-page="${page.id}" title="删除">×</span>`;
  }
  html += `</div></div>`;

  if (children.length > 0) {
    html += '<div class="tree-children">';
    children.forEach(child => {
      html += renderTreeNode(child, depth + 1);
    });
    html += '</div>';
  }

  return html;
}

console.log('StarmoAI Design 渲染引擎已加载');
