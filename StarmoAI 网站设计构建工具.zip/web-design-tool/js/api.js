// ============================================
// StarmoAI Design — 模块化集成API
// 提供外部模块访问和集成的标准接口
// ============================================

(function() {
  'use strict';

  const _listeners = {};
  let _embedMode = false;
  let _ready = false;

  // --- 事件系统 ---
  function on(event, callback) {
    if (!_listeners[event]) _listeners[event] = [];
    _listeners[event].push(callback);
    return () => off(event, callback);
  }

  function off(event, callback) {
    if (!_listeners[event]) return;
    _listeners[event] = _listeners[event].filter(cb => cb !== callback);
  }

  function emit(event, data) {
    (_listeners[event] || []).forEach(cb => {
      try { cb(data); } catch(e) { console.warn('[StarmoAI] Event handler error:', e); }
    });
  }

  // --- 封装原生操作并触发事件 ---
  const _origSaveHistory = typeof saveHistory === 'function' ? saveHistory : null;
  const _origRenderAll = typeof renderAll === 'function' ? renderAll : null;

  function notifyChange(type, detail) {
    emit('change', { type, detail, timestamp: Date.now() });
    // 自动保存
    if (typeof saveProject === 'function') {
      try { saveProject(); } catch(e) {}
    }
  }

  // --- 数据导出 ---
  function exportData() {
    return JSON.parse(JSON.stringify({
      version: 1,
      module: 'starmoai-design',
      exportTime: new Date().toISOString(),
      pages: AppState.pages,
      currentPageId: AppState.currentPageId,
      workflowChecks: AppState.workflowChecks,
      workflowStep: AppState.workflowStep,
    }));
  }

  // --- 数据导入 ---
  function importData(data) {
    if (!data || !data.pages) {
      console.warn('[StarmoAI] Invalid import data');
      return false;
    }
    try {
      AppState.pages = JSON.parse(JSON.stringify(data.pages));
      AppState.currentPageId = data.currentPageId || (AppState.pages[0] && AppState.pages[0].id) || null;
      AppState.workflowChecks = data.workflowChecks || {};
      AppState.workflowStep = data.workflowStep || 0;
      AppState.selectedIds = [];
      AppState.history = [];
      AppState.historyIndex = -1;
      if (typeof saveHistory === 'function') saveHistory();
      if (typeof renderAll === 'function') renderAll();
      notifyChange('import', { pageCount: AppState.pages.length });
      return true;
    } catch(e) {
      console.error('[StarmoAI] Import failed:', e);
      return false;
    }
  }

  // --- 页面操作 ---
  function getPages() {
    return AppState.pages.map(p => ({
      id: p.id, name: p.name,
      width: p.width, height: p.height,
      elementCount: p.elements.length,
      links: p.links,
      backgroundColor: p.backgroundColor,
      meta: p.meta,
    }));
  }

  function getCurrentPageId() {
    return AppState.currentPageId;
  }

  function switchToPage(pageId) {
    if (typeof switchPage === 'function') {
      switchPage(pageId);
      notifyChange('pageSwitch', { pageId });
    }
  }

  function addPage(name, opts) {
    if (typeof createPage === 'function') {
      const page = createPage(name, opts);
      if (typeof renderAll === 'function') renderAll();
      notifyChange('pageAdd', { pageId: page.id, name });
      return page;
    }
    return null;
  }

  // --- 元素操作 ---
  function getElements(pageId) {
    const pid = pageId || AppState.currentPageId;
    const page = AppState.pages.find(p => p.id === pid);
    if (!page) return [];
    return page.elements.map(el => ({
      id: el.id, type: el.type, name: el.name,
      x: el.x, y: el.y, width: el.width, height: el.height,
      visible: el.visible, locked: el.locked,
      content: el.content,
      styles: { ...el.styles },
      animations: el.animations ? [...el.animations] : [],
    }));
  }

  function addElement(type, opts, pageId) {
    const pid = pageId || AppState.currentPageId;
    if (typeof createElement !== 'function') return null;
    const el = createElement(type, opts);
    if (typeof addElementToPage === 'function') addElementToPage(pid, el);
    if (typeof renderAll === 'function') renderAll();
    notifyChange('elementAdd', { elementId: el.id, type, pageId: pid });
    return el;
  }

  function updateElement(elId, updates) {
    const el = typeof getElementById === 'function' ? getElementById(elId) : null;
    if (!el) return false;
    if (updates.styles) {
      Object.assign(el.styles, updates.styles);
      delete updates.styles;
    }
    Object.assign(el, updates);
    if (typeof saveHistory === 'function') saveHistory();
    if (typeof renderAll === 'function') renderAll();
    notifyChange('elementUpdate', { elementId: elId });
    return true;
  }

  function removeElement(elId) {
    if (typeof deleteElements === 'function') {
      deleteElements([elId]);
      notifyChange('elementRemove', { elementId: elId });
    }
  }

  function selectElement(elId) {
    AppState.selectedIds = [elId];
    if (typeof renderAll === 'function') renderAll();
    notifyChange('select', { elementIds: [elId] });
  }

  // --- 获取完整项目数据 ---
  function getProjectData() {
    return {
      pages: AppState.pages,
      currentPageId: AppState.currentPageId,
    };
  }

  // --- 嵌入模式 ---
  function setEmbedMode(enabled) {
    _embedMode = !!enabled;
    const toolbar = document.querySelector('.toolbar');
    if (toolbar) toolbar.style.display = _embedMode ? 'none' : '';
    emit('embedModeChange', { enabled: _embedMode });
  }

  function isEmbedMode() { return _embedMode; }

  // --- 预览控制 ---
  function openPreviewMode(device) {
    if (typeof openPreview === 'function') openPreview(device || 'desktop');
  }

  function closePreviewMode() {
    if (typeof closePreview === 'function') closePreview();
  }

  // --- 导出 ---
  function exportHTML() {
    if (typeof exportHTML === 'function') {
      // 调用全局的 exportHTML
      const fn = window.exportHTML || this.exportHTML;
    }
    // 直接调用全局函数
    if (window.exportHTML) window.exportHTML();
  }

  // --- 注册自定义组件 ---
  const _customComponents = [];
  function registerComponent(componentDef) {
    if (!componentDef || !componentDef.type) return;
    _customComponents.push(componentDef);
    // 动态添加到组件面板
    const grid = document.querySelector('.component-grid');
    if (grid && componentDef.icon && componentDef.label) {
      const item = document.createElement('div');
      item.className = 'component-item';
      item.dataset.type = componentDef.type;
      item.innerHTML = `${componentDef.icon}<span>${componentDef.label}</span>`;
      grid.appendChild(item);
      // 重新绑定拖拽
      if (typeof initDragFromPanel === 'function') initDragFromPanel();
    }
    emit('componentRegister', { type: componentDef.type });
  }

  function getCustomComponents() {
    return [..._customComponents];
  }

  // --- 注册自定义模板 ---
  function registerTemplate(templateDef) {
    if (!templateDef || !templateDef.name || !templateDef.pages) return;
    if (typeof TEMPLATES !== 'undefined') TEMPLATES.push(templateDef);
    emit('templateRegister', { name: templateDef.name });
  }

  // --- 状态查询 ---
  function getState() {
    return {
      selectedIds: [...AppState.selectedIds],
      zoom: AppState.zoom,
      tool: AppState.tool,
      currentPageId: AppState.currentPageId,
      pageCount: AppState.pages.length,
    };
  }

  // --- 暴露全局API ---
  const StarmoAIDesign = {
    // 事件
    on, off, emit,
    // 数据
    exportData, importData, getProjectData, getState,
    // 页面
    getPages, getCurrentPageId, switchToPage, addPage,
    // 元素
    getElements, addElement, updateElement, removeElement, selectElement,
    // 扩展
    registerComponent, getCustomComponents, registerTemplate,
    // 模式
    setEmbedMode, isEmbedMode,
    // 预览
    openPreview: openPreviewMode, closePreview: closePreviewMode,
    // 导出
    exportHTML: function() { if (window.exportHTML) window.exportHTML(); },
    // 版本
    version: '1.0.0',
    moduleName: 'starmoai-design',
  };

  window.StarmoAIDesign = StarmoAIDesign;

  // 触发就绪事件
  setTimeout(() => {
    _ready = true;
    emit('ready', { version: StarmoAIDesign.version });
    console.log('[StarmoAI] Design module ready. Access via window.StarmoAIDesign');
  }, 100);

  console.log('StarmoAI Design API 已加载');
})();