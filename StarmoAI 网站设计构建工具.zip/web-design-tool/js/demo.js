// ============================================
// StarmoAI Design - Demo 示例数据
// ============================================

function loadDemoProject() {
  // 清空
  AppState.pages = [];
  AppState.history = [];
  AppState.historyIndex = -1;
  AppState.workflowChecks = {};
  AppState.workflowStep = 4; // 已完成到"组件搭建"步骤

  // ========== 页面1：首页 ==========
  const home = createPage('首页', { width: 1440, height: 1024 });
  home.backgroundColor = '#ffffff';
  home.meta = { title: 'StarmoAI - 智能设计平台', description: '下一代AI驱动的网页设计工具', keywords: 'AI,设计,网页' };

  // 页头导航
  addElementToPage(home.id, createElement('header', {
    x: 0, y: 0, width: 1440, height: 64,
    name: '导航栏',
    styles: { backgroundColor: '#0c0e1a', color: '#ffffff', borderWidth: 0 }
  }));

  // Hero区域
  addElementToPage(home.id, createElement('box', {
    x: 0, y: 64, width: 1440, height: 520,
    name: 'Hero背景',
    styles: { backgroundColor: 'linear-gradient(135deg, #0c0e1a 0%, #1a1040 40%, #0c0e1a 100%)', borderWidth: 0 }
  }));

  addElementToPage(home.id, createElement('heading', {
    x: 160, y: 180, width: 600, height: 52,
    name: '主标题', content: '用AI重新定义\n网页设计体验',
    styles: { backgroundColor: 'transparent', color: '#ffffff', fontSize: 42, fontWeight: '700', lineHeight: 1.3, borderWidth: 0, letterSpacing: -0.5 }
  }));

  addElementToPage(home.id, createElement('paragraph', {
    x: 160, y: 270, width: 500, height: 50,
    name: '副标题', content: '拖拽式可视化设计，支持多页面导航、组件库、动效编辑、代码导出。零依赖纯手搓，让创意自由飞翔。',
    styles: { backgroundColor: 'transparent', color: '#9ca3c4', fontSize: 15, lineHeight: 1.6, borderWidth: 0 }
  }));

  addElementToPage(home.id, createElement('button', {
    x: 160, y: 350, width: 180, height: 48,
    name: 'CTA按钮', content: '免费开始设计',
    styles: { backgroundColor: '#7c5cfc', color: '#ffffff', borderRadius: 10, fontSize: 15, fontWeight: '600', borderWidth: 0, boxShadow: '0 4px 20px rgba(124,92,252,0.4)' },
    animations: [{ type: 'fadeIn', duration: 0.8, delay: 0.3, easing: 'ease' }],
    linkToPage: ''
  }));

  addElementToPage(home.id, createElement('button', {
    x: 360, y: 350, width: 160, height: 48,
    name: '次按钮', content: '查看模板',
    styles: { backgroundColor: 'transparent', color: '#9ca3c4', borderRadius: 10, fontSize: 15, fontWeight: '500', borderWidth: 1, borderColor: '#2a2f55', borderStyle: 'solid' },
    linkToPage: ''
  }));

  // 右侧预览图区域
  addElementToPage(home.id, createElement('card', {
    x: 820, y: 140, width: 460, height: 370,
    name: '产品预览卡片',
    styles: { backgroundColor: '#131630', borderRadius: 16, borderWidth: 1, borderColor: '#2a2f55', boxShadow: '0 16px 48px rgba(0,0,0,0.4)', padding: 0 }
  }));

  addElementToPage(home.id, createElement('box', {
    x: 840, y: 160, width: 420, height: 240,
    name: '预览图占位',
    styles: { backgroundColor: '#1a1d3a', borderRadius: 10, borderWidth: 0 },
    animations: [{ type: 'slideInRight', duration: 0.6, delay: 0.5, easing: 'ease' }]
  }));

  // 特性区块
  addElementToPage(home.id, createElement('section', {
    x: 0, y: 620, width: 1440, height: 400,
    name: '特性区块',
    styles: { backgroundColor: '#f8f9fc', borderWidth: 0, padding: 0 }
  }));

  addElementToPage(home.id, createElement('heading', {
    x: 570, y: 650, width: 300, height: 36,
    name: '特性标题', content: '强大功能，简单操作',
    styles: { backgroundColor: 'transparent', color: '#1a1a2e', fontSize: 28, fontWeight: '700', textAlign: 'center', borderWidth: 0 }
  }));

  // 3个特性卡片
  const features = [
    { name: '拖拽设计', desc: '16+组件，自由拖拽', x: 120 },
    { name: '多页面导航', desc: '树状图管理跳转', x: 520 },
    { name: '一键导出', desc: '导出HTML代码', x: 920 },
  ];
  features.forEach(f => {
    addElementToPage(home.id, createElement('card', {
      x: f.x, y: 710, width: 320, height: 200,
      name: f.name + '卡片',
      styles: { backgroundColor: '#ffffff', borderRadius: 14, borderWidth: 0, boxShadow: '0 4px 20px rgba(0,0,0,0.06)', padding: 0 },
      animations: [{ type: 'slideInUp', duration: 0.5, delay: 0.1, easing: 'ease' }]
    }));
    addElementToPage(home.id, createElement('box', {
      x: f.x + 130, y: 740, width: 60, height: 60,
      name: '图标',
      styles: { backgroundColor: 'rgba(124,92,252,0.1)', borderRadius: 14, borderWidth: 0 }
    }));
    addElementToPage(home.id, createElement('heading', {
      x: f.x + 30, y: 820, width: 260, height: 28,
      name: '特性名', content: f.name,
      styles: { backgroundColor: 'transparent', color: '#1a1a2e', fontSize: 18, fontWeight: '600', textAlign: 'center', borderWidth: 0 }
    }));
    addElementToPage(home.id, createElement('paragraph', {
      x: f.x + 30, y: 855, width: 260, height: 24,
      name: '特性描述', content: f.desc,
      styles: { backgroundColor: 'transparent', color: '#6a6a8a', fontSize: 13, textAlign: 'center', borderWidth: 0 }
    }));
  });

  // 页脚
  addElementToPage(home.id, createElement('footer', {
    x: 0, y: 964, width: 1440, height: 60,
    name: '页脚',
    styles: { backgroundColor: '#0c0e1a', color: '#5a6080', borderWidth: 0 }
  }));

  // ========== 页面2：功能详情 ==========
  const featuresPage = createPage('功能详情', { width: 1440, height: 900 });
  featuresPage.backgroundColor = '#ffffff';
  home.links.push({ fromId: home.id, toPageId: featuresPage.id, label: '跳转到功能详情' });

  addElementToPage(featuresPage.id, createElement('header', {
    x: 0, y: 0, width: 1440, height: 64,
    name: '导航栏',
    styles: { backgroundColor: '#0c0e1a', color: '#ffffff', borderWidth: 0 }
  }));

  addElementToPage(featuresPage.id, createElement('heading', {
    x: 100, y: 120, width: 500, height: 42,
    name: '页面标题', content: '功能详情',
    styles: { backgroundColor: 'transparent', color: '#1a1a2e', fontSize: 36, fontWeight: '700', borderWidth: 0 }
  }));

  addElementToPage(featuresPage.id, createElement('paragraph', {
    x: 100, y: 175, width: 600, height: 30,
    name: '页面描述', content: '探索 StarmoAI Design 的全部功能模块',
    styles: { backgroundColor: 'transparent', color: '#6a6a8a', fontSize: 16, borderWidth: 0 }
  }));

  // 功能列表卡片
  const featureItems = [
    { title: '可视化画布', desc: '自由拖拽、缩放、对齐，支持多元素同时操作和框选', y: 240 },
    { title: '组件库', desc: '16+ 预置组件，支持自定义扩展', y: 360 },
    { title: '页面导航树', desc: '树状图管理多页面，可视化跳转关系', y: 480 },
    { title: '动效编辑', desc: '10+ 种入场动画，实时预览效果', y: 600 },
  ];
  featureItems.forEach((item, i) => {
    addElementToPage(featuresPage.id, createElement('card', {
      x: 100, y: item.y, width: 600, height: 90,
      name: '功能项 ' + (i + 1),
      styles: { backgroundColor: '#f8f9fc', borderRadius: 12, borderWidth: 0, boxShadow: 'none', padding: 0 },
      animations: [{ type: 'slideInLeft', duration: 0.4, delay: i * 0.1, easing: 'ease' }]
    }));
    addElementToPage(featuresPage.id, createElement('heading', {
      x: 130, y: item.y + 20, width: 200, height: 24,
      name: '功能名', content: item.title,
      styles: { backgroundColor: 'transparent', color: '#1a1a2e', fontSize: 16, fontWeight: '600', borderWidth: 0 }
    }));
    addElementToPage(featuresPage.id, createElement('paragraph', {
      x: 130, y: item.y + 50, width: 500, height: 20,
      name: '功能描述', content: item.desc,
      styles: { backgroundColor: 'transparent', color: '#6a6a8a', fontSize: 13, borderWidth: 0 }
    }));
  });

  // 右侧截图区域
  addElementToPage(featuresPage.id, createElement('box', {
    x: 760, y: 240, width: 580, height: 450,
    name: '功能截图',
    styles: { backgroundColor: '#131630', borderRadius: 16, borderWidth: 1, borderColor: '#2a2f55', boxShadow: '0 8px 32px rgba(0,0,0,0.15)' },
    animations: [{ type: 'zoomIn', duration: 0.6, delay: 0.2, easing: 'ease' }]
  }));

  // 返回按钮
  addElementToPage(featuresPage.id, createElement('button', {
    x: 100, y: 750, width: 160, height: 44,
    name: '返回首页', content: '← 返回首页',
    styles: { backgroundColor: '#7c5cfc', color: '#ffffff', borderRadius: 10, fontSize: 14, fontWeight: '500', borderWidth: 0 },
    linkToPage: home.id
  }));

  addElementToPage(featuresPage.id, createElement('footer', {
    x: 0, y: 840, width: 1440, height: 60,
    name: '页脚',
    styles: { backgroundColor: '#0c0e1a', color: '#5a6080', borderWidth: 0 }
  }));

  // ========== 页面3：定价 ==========
  const pricingPage = createPage('定价方案', { width: 1440, height: 900 });
  pricingPage.backgroundColor = '#f8f9fc';
  featuresPage.links.push({ fromId: featuresPage.id, toPageId: pricingPage.id, label: '跳转到定价' });

  addElementToPage(pricingPage.id, createElement('header', {
    x: 0, y: 0, width: 1440, height: 64,
    name: '导航栏',
    styles: { backgroundColor: '#0c0e1a', color: '#ffffff', borderWidth: 0 }
  }));

  addElementToPage(pricingPage.id, createElement('heading', {
    x: 420, y: 120, width: 600, height: 42,
    name: '定价标题', content: '选择适合你的方案',
    styles: { backgroundColor: 'transparent', color: '#1a1a2e', fontSize: 32, fontWeight: '700', textAlign: 'center', borderWidth: 0 }
  }));

  // 3个定价卡片
  const plans = [
    { name: '免费版', price: '免费', features: '基础组件\n单页面设计\nHTML导出', x: 160, highlight: false },
    { name: '专业版', price: '¥99/月', features: '全部组件\n无限页面\n动效编辑\n优先支持', x: 540, highlight: true },
    { name: '企业版', price: '¥399/月', features: '全部专业版功能\n团队协作\n自定义组件\n专属客服', x: 920, highlight: false },
  ];
  plans.forEach(p => {
    addElementToPage(pricingPage.id, createElement('card', {
      x: p.x, y: 220, width: 320, height: 460,
      name: p.name + '方案',
      styles: {
        backgroundColor: p.highlight ? '#0c0e1a' : '#ffffff',
        borderRadius: 16, borderWidth: p.highlight ? 2 : 0,
        borderColor: '#7c5cfc',
        boxShadow: p.highlight ? '0 8px 32px rgba(124,92,252,0.3)' : '0 4px 20px rgba(0,0,0,0.06)',
        padding: 0,
      },
      animations: [{ type: 'slideInUp', duration: 0.5, delay: 0.1, easing: 'ease' }]
    }));
    addElementToPage(pricingPage.id, createElement('paragraph', {
      x: p.x + 40, y: 260, width: 240, height: 24,
      name: '方案名', content: p.name,
      styles: { backgroundColor: 'transparent', color: p.highlight ? '#9ca3c4' : '#6a6a8a', fontSize: 14, fontWeight: '500', textAlign: 'center', borderWidth: 0 }
    }));
    addElementToPage(pricingPage.id, createElement('heading', {
      x: p.x + 40, y: 300, width: 240, height: 40,
      name: '价格', content: p.price,
      styles: { backgroundColor: 'transparent', color: p.highlight ? '#ffffff' : '#1a1a2e', fontSize: 32, fontWeight: '800', textAlign: 'center', borderWidth: 0 }
    }));
    addElementToPage(pricingPage.id, createElement('divider', {
      x: p.x + 40, y: 360, width: 240, height: 2,
      name: '分割线',
      styles: { backgroundColor: p.highlight ? '#2a2f55' : '#e0e0e0', borderWidth: 0 }
    }));
    addElementToPage(pricingPage.id, createElement('paragraph', {
      x: p.x + 40, y: 390, width: 240, height: 200,
      name: '功能列表', content: p.features,
      styles: { backgroundColor: 'transparent', color: p.highlight ? '#9ca3c4' : '#6a6a8a', fontSize: 14, lineHeight: 2.2, borderWidth: 0 }
    }));
    addElementToPage(pricingPage.id, createElement('button', {
      x: p.x + 50, y: 620, width: 220, height: 42,
      name: '选择方案', content: p.highlight ? '立即订阅' : '选择方案',
      styles: {
        backgroundColor: p.highlight ? '#7c5cfc' : 'transparent',
        color: p.highlight ? '#ffffff' : '#7c5cfc',
        borderRadius: 10, fontSize: 14, fontWeight: '600',
        borderWidth: p.highlight ? 0 : 2, borderColor: '#7c5cfc', borderStyle: 'solid'
      },
      linkToPage: ''
    }));
  });

  addElementToPage(pricingPage.id, createElement('button', {
    x: 100, y: 750, width: 160, height: 44,
    name: '返回功能页', content: '← 功能详情',
    styles: { backgroundColor: 'transparent', color: '#7c5cfc', borderRadius: 10, fontSize: 14, fontWeight: '500', borderWidth: 2, borderColor: '#7c5cfc', borderStyle: 'solid' },
    linkToPage: featuresPage.id
  }));

  addElementToPage(pricingPage.id, createElement('footer', {
    x: 0, y: 840, width: 1440, height: 60,
    name: '页脚',
    styles: { backgroundColor: '#0c0e1a', color: '#5a6080', borderWidth: 0 }
  }));

  // 设置首页为当前页
  AppState.currentPageId = home.id;
  AppState.selectedIds = [];

  // 工作流进度
  AppState.workflowChecks = {
    research: [0,1,2,3,4],
    sitemap: [0,1,2,3,4],
    wireframe: [0,1,2,3,4],
    visual: [0,1,2,3,4],
    components: [0,1,2,3,4],
    interaction: [],
    responsive: [],
    review: [],
  };
  AppState.workflowStep = 5;

  saveHistory();
}
