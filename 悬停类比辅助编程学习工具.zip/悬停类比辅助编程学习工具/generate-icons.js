const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function createPNG(size) {
  const width = size;
  const height = size;

  const rawData = [];
  for (let y = 0; y < height; y++) {
    rawData.push(0);
    for (let x = 0; x < width; x++) {
      const nx = x / width;
      const ny = y / height;

      if (nx >= 0.156 && nx <= 0.844 && ny >= 0.117 && ny <= 0.883) {
        const inBorder = (nx < 0.188 || nx > 0.812 || ny < 0.148 || ny > 0.852);
        if (inBorder) {
          rawData.push(233, 69, 96, 255);
        } else {
          const lineY1 = Math.abs(ny - 0.3125) < 0.02;
          const lineY2 = Math.abs(ny - 0.453) < 0.015;
          const lineY3 = Math.abs(ny - 0.5625) < 0.015;
          const lineY4 = Math.abs(ny - 0.672) < 0.015;

          if (lineY1) {
            rawData.push(233, 69, 96, 255);
          } else if (lineY2 || lineY3 || lineY4) {
            rawData.push(74, 144, 217, 255);
          } else {
            rawData.push(15, 52, 96, 255);
          }
        }
      } else {
        const dx = nx - 0.703;
        const dy = ny - 0.703;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 0.172) {
          rawData.push(233, 69, 96, 255);
        } else {
          rawData.push(26, 26, 46, 255);
        }
      }
    }
  }

  const raw = Buffer.from(rawData);
  const deflated = zlib.deflateSync(raw);

  const chunks = [];

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  chunks.push(signature);

  function createChunk(type, data) {
    const typeBuffer = Buffer.from(type, 'ascii');
    const length = Buffer.alloc(4);
    length.writeUInt32BE(data.length, 0);
    const crcData = Buffer.concat([typeBuffer, data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(crcData), 0);
    return Buffer.concat([length, typeBuffer, data, crc]);
  }

  function crc32(buf) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) {
      crc ^= buf[i];
      for (let j = 0; j < 8; j++) {
        crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
      }
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  chunks.push(createChunk('IHDR', ihdr));
  chunks.push(createChunk('IDAT', deflated));
  chunks.push(createChunk('IEND', Buffer.alloc(0)));

  return Buffer.concat(chunks);
}

const sizes = [16, 48, 128];
const iconsDir = path.join(__dirname, 'icons');

sizes.forEach(s => {
  const png = createPNG(s);
  fs.writeFileSync(path.join(iconsDir, `icon${s}.png`), png);
  console.log(`icon${s}.png created (${png.length} bytes)`);
});
