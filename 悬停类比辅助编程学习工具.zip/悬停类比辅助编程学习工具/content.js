if (window.__docGrabberV2) {
} else {
  window.__docGrabberV2 = true;
}

function resolveUrl(src) {
  if (!src) return '';
  try {
    return new URL(src, location.href).href;
  } catch (e) {
    return src;
  }
}

var ICON_CLASSES = [
  'icon', 'logo', 'avatar', 'badge', 'favicon', 'emoji',
  'social', 'share', 'arrow', 'chevron', 'breadcrumb',
  'spinner', 'loading', 'placeholder', 'thumb', 'thumbnail',
  'profile', 'user-icon', 'menu-icon', 'nav-icon', 'close',
  'search-icon', 'hamburger', 'toggle', 'caret', 'dropdown'
];

var ICON_SRCS = [
  'icon', 'logo', 'avatar', 'favicon', 'emoji', 'sprite',
  'placeholder', 'blank', 'spacer', 'pixel', 'tracking',
  'beacon', '1x1', 'transparent', 'spinner', 'loading',
  'arrow', 'chevron', 'social', 'share', 'breadcrumb'
];

var ICON_ALTS = [
  'icon', 'logo', 'avatar', 'badge', 'arrow', 'chevron',
  'menu', 'close', 'search', 'hamburger', 'toggle', 'caret',
  'spinner', 'loading', 'more', 'dropdown', 'breadcrumb'
];

function isJunkImage(img) {
  var w = img.naturalWidth || img.width || parseInt(img.getAttribute('width')) || 0;
  var h = img.naturalHeight || img.height || parseInt(img.getAttribute('height')) || 0;

  if (w > 0 && h > 0 && (w < 30 || h < 30)) return true;

  var src = (img.getAttribute('src') || img.getAttribute('data-src') || '').toLowerCase();
  if (src.endsWith('.svg') && w > 0 && w < 40) return true;

  var cls = (img.className || '').toLowerCase();
  var id = (img.id || '').toLowerCase();
  var alt = (img.getAttribute('alt') || '').toLowerCase();
  var combined = cls + ' ' + id + ' ' + alt;

  for (var i = 0; i < ICON_CLASSES.length; i++) {
    var pattern = ICON_CLASSES[i];
    var regex = new RegExp('(?:^|[\-_ ])' + pattern + '(?:[\-_ ]|$)', 'i');
    if (regex.test(combined)) return true;
  }

  for (var j = 0; j < ICON_SRCS.length; j++) {
    if (src.indexOf('/' + ICON_SRCS[j]) !== -1 || src.indexOf('-' + ICON_SRCS[j]) !== -1) return true;
  }

  for (var k = 0; k < ICON_ALTS.length; k++) {
    if (alt === ICON_ALTS[k]) return true;
  }

  if (img.parentElement) {
    var parentTag = img.parentElement.tagName.toLowerCase();
    var parentCls = (img.parentElement.className || '').toLowerCase();
    if (parentTag === 'button' || parentTag === 'a') {
      var parentText = (img.parentElement.textContent || '').trim();
      if (parentText.length > 10) return false;
      if (w > 0 && w < 40) return true;
    }
    if (/nav|header|footer|sidebar|toolbar|breadcrumb/i.test(parentCls)) return true;
  }

  var role = img.getAttribute('role');
  if (role === 'presentation' || role === 'none') return true;

  if (img.getAttribute('aria-hidden') === 'true') return true;

  return false;
}

function findArticle() {
  var selectors = [
    'article',
    '[role="main"]',
    '.markdown-body',
    '.doc-content',
    '.documentation',
    '.document-body',
    '.lesson-content',
    '.course-content',
    '.chapter-content',
    '.content-body',
    '.post-content',
    '.entry-content',
    '.article-content',
    '.topic-content',
    '.page-content',
    'main',
    '#content',
    '#main',
    '#doc-content'
  ];
  for (var i = 0; i < selectors.length; i++) {
    var el = document.querySelector(selectors[i]);
    if (el && el.innerText && el.innerText.length > 200) return el;
  }
  return document.body;
}

function cleanHtml(clone) {
  var removeSelectors = [
    'script', 'style', 'noscript', 'iframe',
    'nav', 'header', 'footer',
    '.sidebar', '.side-bar', '.aside',
    '.toc', '.table-of-contents',
    '.navigation', '.nav-bar', '.navbar', '.nav-links',
    '.ads', '.ad-banner', '.advertisement', '.ad-wrapper',
    '.cookie-banner', '.cookie-notice', '.cookie-consent',
    '.popup', '.modal', '.overlay', '.dialog',
    '.social-share', '.share-buttons', '.share-bar',
    '.comments', '.comment-section', '.disqus',
    '.breadcrumb', '.breadcrumbs',
    '.toolbar', '.tool-bar', '.action-bar',
    '.page-nav', '.pagination',
    '.site-header', '.site-footer', '.site-nav',
    '.header-bar', '.top-bar', '.bottom-bar',
    '.search-box', '.search-form',
    '.back-to-top', '.scroll-top',
    '.related-posts', '.related-content',
    '.author-info', '.author-bio',
    '.tags', '.tag-list',
    '.print-btn', '.edit-btn',
    '[role="navigation"]', '[role="banner"]', '[role="contentinfo"]',
    '[role="toolbar"]', '[role="search"]',
    '[aria-label="Skip"]', '[aria-label="Search"]',
    'svg.icon', 'svg[aria-hidden="true"]'
  ];
  for (var i = 0; i < removeSelectors.length; i++) {
    var els = clone.querySelectorAll(removeSelectors[i]);
    for (var j = 0; j < els.length; j++) {
      els[j].remove();
    }
  }

  var imgs = clone.querySelectorAll('img');
  for (var m = imgs.length - 1; m >= 0; m--) {
    if (isJunkImage(imgs[m])) {
      imgs[m].remove();
      continue;
    }
    var src = imgs[m].getAttribute('data-src') || imgs[m].getAttribute('data-original') || imgs[m].getAttribute('src') || '';
    if (src) {
      imgs[m].setAttribute('src', resolveUrl(src));
    }
    imgs[m].removeAttribute('srcset');
    imgs[m].removeAttribute('loading');
    imgs[m].removeAttribute('class');
    imgs[m].removeAttribute('data-src');
    imgs[m].removeAttribute('data-original');
    imgs[m].removeAttribute('width');
    imgs[m].removeAttribute('height');
    imgs[m].style.maxWidth = '100%';
    imgs[m].style.height = 'auto';
  }

  var svgs = clone.querySelectorAll('svg');
  for (var sv = svgs.length - 1; sv >= 0; sv--) {
    var svgW = parseInt(svgs[sv].getAttribute('width')) || 0;
    var svgH = parseInt(svgs[sv].getAttribute('height')) || 0;
    if (svgW < 40 || svgH < 40 || svgs[sv].getAttribute('aria-hidden') === 'true') {
      svgs[sv].remove();
    }
  }

  var allEls = clone.querySelectorAll('*');
  for (var k = 0; k < allEls.length; k++) {
    allEls[k].removeAttribute('onclick');
    allEls[k].removeAttribute('onload');
    allEls[k].removeAttribute('onerror');
    allEls[k].removeAttribute('data-testid');
  }

  var pres = clone.querySelectorAll('pre');
  for (var n = 0; n < pres.length; n++) {
    pres[n].style.background = '#f8f8f8';
    pres[n].style.border = '1px solid #e0e0e0';
    pres[n].style.borderRadius = '4px';
    pres[n].style.padding = '12px 16px';
    pres[n].style.overflowX = 'auto';
    pres[n].style.fontFamily = 'Consolas, "Courier New", monospace';
    pres[n].style.fontSize = '13px';
    pres[n].style.lineHeight = '1.5';
    pres[n].style.whiteSpace = 'pre-wrap';
    pres[n].style.wordWrap = 'break-word';
  }

  var codes = clone.querySelectorAll('code');
  for (var p = 0; p < codes.length; p++) {
    if (codes[p].parentElement && codes[p].parentElement.tagName.toLowerCase() === 'pre') continue;
    codes[p].style.background = '#f0f0f0';
    codes[p].style.padding = '2px 6px';
    codes[p].style.borderRadius = '3px';
    codes[p].style.fontFamily = 'Consolas, "Courier New", monospace';
    codes[p].style.fontSize = '13px';
  }

  var tables = clone.querySelectorAll('table');
  for (var q = 0; q < tables.length; q++) {
    tables[q].style.borderCollapse = 'collapse';
    tables[q].style.width = '100%';
    tables[q].style.margin = '16px 0';
    var cells = tables[q].querySelectorAll('th, td');
    for (var r = 0; r < cells.length; r++) {
      cells[r].style.border = '1px solid #ccc';
      cells[r].style.padding = '8px 12px';
    }
    var ths = tables[q].querySelectorAll('th');
    for (var s = 0; s < ths.length; s++) {
      ths[s].style.background = '#f5f5f5';
    }
  }

  return clone;
}

function extractPage(nextSelector) {
  var article = findArticle();
  var clone = article.cloneNode(true);
  clone = cleanHtml(clone);

  var images = [];
  var imgs = clone.querySelectorAll('img');
  for (var i = 0; i < imgs.length; i++) {
    var src = imgs[i].getAttribute('src') || '';
    if (src) {
      images.push(src);
    }
  }

  var nextUrl = findNextLink(nextSelector);

  return {
    title: document.title || '未命名文档',
    url: location.href,
    html: clone.innerHTML,
    images: images,
    nextUrl: nextUrl
  };
}

function extractSelection() {
  var selection = window.getSelection();
  if (!selection || selection.rangeCount === 0 || selection.toString().trim() === '') {
    return { success: false, error: '没有选中内容' };
  }
  var range = selection.getRangeAt(0);
  var container = document.createElement('div');
  container.appendChild(range.cloneContents());
  container = cleanHtml(container);

  var images = [];
  var imgs = container.querySelectorAll('img');
  for (var i = 0; i < imgs.length; i++) {
    var src = imgs[i].getAttribute('src') || '';
    if (src) images.push(src);
  }

  return {
    success: true,
    data: {
      title: document.title + ' (选区)',
      url: location.href,
      html: container.innerHTML,
      images: images,
      nextUrl: null
    }
  };
}

function findNextLink(customSelector) {
  if (customSelector) {
    var el = document.querySelector(customSelector);
    if (el && el.href) return el.href;
  }

  var autoSelectors = [
    'a[rel="next"]',
    'a.next',
    'a.next-page',
    'a.next-page-link',
    'a.pagination-next',
    'a.page-next',
    'a.btn-next',
    'a[aria-label="Next"]',
    'a[aria-label="下一页"]',
    'a[aria-label="下一节"]',
    'a[aria-label="下一课"]',
    '.pagination .next a',
    '.pager .next a',
    '.page-nav .next a',
    '.lesson-nav .next a',
    '.course-nav .next a'
  ];

  for (var i = 0; i < autoSelectors.length; i++) {
    var el = document.querySelector(autoSelectors[i]);
    if (el && el.href) return el.href;
  }

  var links = document.querySelectorAll('a');
  var nextTexts = ['下一节', '下一课', '下一页', '下一章', 'next', 'next page', 'next lesson', 'next chapter', '后一页', '继续'];
  for (var j = 0; j < links.length; j++) {
    var text = links[j].textContent.trim().toLowerCase();
    var href = links[j].href;
    if (!href || href === location.href || href === '#') continue;
    for (var k = 0; k < nextTexts.length; k++) {
      if (text === nextTexts[k]) {
        return href;
      }
    }
  }

  return null;
}

function extractTocLinks(tocSelector) {
  if (!tocSelector) return [];
  var links = document.querySelectorAll(tocSelector + ' a, ' + tocSelector);
  var result = [];
  var seen = {};
  for (var i = 0; i < links.length; i++) {
    var href = links[i].href;
    var text = links[i].textContent.trim();
    if (href && !seen[href] && text) {
      seen[href] = true;
      result.push({ url: href, title: text });
    }
  }
  return result;
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === 'extractPage') {
    try {
      var result = extractPage(request.nextSelector);
      sendResponse({ success: true, data: result });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }

  if (request.action === 'extractSelection') {
    try {
      var result = extractSelection();
      sendResponse(result);
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }

  if (request.action === 'extractTocLinks') {
    try {
      var links = extractTocLinks(request.tocSelector);
      sendResponse({ success: true, links: links });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }
});
