(function () {
  var statusEl = document.getElementById('status');
  var progressBar = document.getElementById('progressBar');
  var progressFill = document.getElementById('progressFill');
  var btnGrabAll = document.getElementById('btnGrabAll');
  var btnGrabSelection = document.getElementById('btnGrabSelection');
  var btnStartCrawl = document.getElementById('btnStartCrawl');
  var btnStopCrawl = document.getElementById('btnStopCrawl');
  var btnAiOrganize = document.getElementById('btnAiOrganize');
  var crawlModeSelect = document.getElementById('crawlMode');
  var nextSelectorInput = document.getElementById('nextSelector');
  var tocSelectorInput = document.getElementById('tocSelector');
  var maxPagesInput = document.getElementById('maxPages');
  var nextSelectorGroup = document.getElementById('nextSelectorGroup');
  var tocSelectorGroup = document.getElementById('tocSelectorGroup');
  var toggleAi = document.getElementById('toggleAi');
  var aiSection = document.getElementById('aiSection');
  var apiUrlInput = document.getElementById('apiUrl');
  var apiKeyInput = document.getElementById('apiKey');
  var aiModelInput = document.getElementById('aiModel');
  var aiPromptInput = document.getElementById('aiPrompt');
  var formatOptions = document.querySelectorAll('.format-option');

  var currentFormat = 'html';
  var pollTimer = null;

  formatOptions.forEach(function (opt) {
    opt.addEventListener('click', function () {
      formatOptions.forEach(function (o) { o.classList.remove('active'); });
      opt.classList.add('active');
      currentFormat = opt.getAttribute('data-format');
    });
  });

  toggleAi.addEventListener('click', function () {
    var visible = aiSection.classList.contains('visible');
    aiSection.classList.toggle('visible');
    toggleAi.textContent = visible ? '展开设置' : '收起设置';
  });

  function loadSettings() {
    try {
      var s = JSON.parse(localStorage.getItem('docGrabberSettings') || '{}');
      if (s.apiUrl) apiUrlInput.value = s.apiUrl;
      if (s.apiKey) apiKeyInput.value = s.apiKey;
      if (s.aiModel) aiModelInput.value = s.aiModel;
      if (s.aiPrompt) aiPromptInput.value = s.aiPrompt;
      if (s.format) {
        currentFormat = s.format;
        formatOptions.forEach(function (o) {
          o.classList.toggle('active', o.getAttribute('data-format') === s.format);
        });
      }
    } catch (e) {}
  }

  function saveSettings() {
    var s = {
      apiUrl: apiUrlInput.value.trim(),
      apiKey: apiKeyInput.value.trim(),
      aiModel: aiModelInput.value.trim(),
      aiPrompt: aiPromptInput.value.trim(),
      format: currentFormat
    };
    localStorage.setItem('docGrabberSettings', JSON.stringify(s));
  }

  loadSettings();

  function showStatus(type, msg) {
    statusEl.className = 'status ' + type;
    statusEl.textContent = msg;
  }

  function setProgress(current, total) {
    progressBar.className = 'progress-bar active';
    var pct = total > 0 ? Math.min((current / total) * 100, 100) : 0;
    progressFill.style.width = pct + '%';
  }

  function hideProgress() {
    progressBar.className = 'progress-bar';
    progressFill.style.width = '0%';
  }

  function setButtonsDisabled(disabled) {
    btnGrabAll.disabled = disabled;
    btnGrabSelection.disabled = disabled;
    btnStartCrawl.disabled = disabled;
    btnAiOrganize.disabled = disabled;
    btnStopCrawl.style.display = disabled ? 'flex' : 'none';
    btnStartCrawl.style.display = disabled ? 'none' : 'flex';
  }

  crawlModeSelect.addEventListener('change', function () {
    var mode = crawlModeSelect.value;
    nextSelectorGroup.style.display = mode === 'next' ? 'block' : 'none';
    tocSelectorGroup.style.display = mode === 'toc' ? 'block' : 'none';
  });

  function getCurrentTab(cb) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs || !tabs[0]) {
        showStatus('error', '无法获取当前标签页');
        return;
      }
      var tab = tabs[0];
      if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('chrome-extension://'))) {
        showStatus('error', '无法在浏览器内部页面上使用');
        return;
      }
      cb(tab);
    });
  }

  function startPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(function () {
      chrome.runtime.sendMessage({ action: 'getCrawlStatus' }, function (state) {
        if (!state) return;

        if (state.isCrawling || state.status === 'processing') {
          showStatus('loading', state.message);
          setButtonsDisabled(true);

          if (state.status === 'crawling' && state.totalPages > 0) {
            setProgress(state.currentPage, state.totalPages);
          } else if (state.status === 'processing') {
            setProgress(80, 100);
          }
        } else if (state.status === 'done') {
          showStatus('success', state.message);
          hideProgress();
          setButtonsDisabled(false);
          stopPolling();
        } else if (state.status === 'error') {
          showStatus('error', state.message);
          hideProgress();
          setButtonsDisabled(false);
          stopPolling();
        }
      });
    }, 500);
  }

  function stopPolling() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  function getAiSettings() {
    return {
      apiUrl: apiUrlInput.value.trim(),
      apiKey: apiKeyInput.value.trim(),
      aiModel: aiModelInput.value.trim() || 'gpt-4o-mini',
      aiPrompt: aiPromptInput.value.trim()
    };
  }

  btnGrabAll.addEventListener('click', function () {
    saveSettings();
    showStatus('loading', '正在抓取当前页...');
    setButtonsDisabled(true);
    hideProgress();

    getCurrentTab(function (tab) {
      chrome.runtime.sendMessage({
        action: 'grabSingle',
        tabId: tab.id,
        format: currentFormat
      }, function (resp) {
        if (resp && resp.started) {
          startPolling();
        } else {
          showStatus('error', '启动失败');
          setButtonsDisabled(false);
        }
      });
    });
  });

  btnGrabSelection.addEventListener('click', function () {
    saveSettings();
    showStatus('loading', '正在抓取选区...');
    setButtonsDisabled(true);
    hideProgress();

    getCurrentTab(function (tab) {
      chrome.runtime.sendMessage({
        action: 'grabSelection',
        tabId: tab.id,
        format: currentFormat
      }, function (resp) {
        if (resp && resp.started) {
          startPolling();
        } else {
          showStatus('error', '启动失败');
          setButtonsDisabled(false);
        }
      });
    });
  });

  btnStartCrawl.addEventListener('click', function () {
    saveSettings();
    var mode = crawlModeSelect.value;
    var nextSelector = nextSelectorInput.value.trim();
    var tocSelector = tocSelectorInput.value.trim();
    var maxPages = parseInt(maxPagesInput.value) || 20;

    if (mode === 'toc' && !tocSelector) {
      showStatus('error', '按目录抓取模式需要填写目录选择器');
      return;
    }

    showStatus('loading', '正在启动批量抓取...');
    setButtonsDisabled(true);

    getCurrentTab(function (tab) {
      chrome.runtime.sendMessage({
        action: 'startCrawl',
        tabId: tab.id,
        maxPages: maxPages,
        nextSelector: nextSelector,
        tocSelector: tocSelector,
        mode: mode,
        format: currentFormat
      }, function (resp) {
        if (resp && resp.started) {
          startPolling();
        } else {
          showStatus('error', '启动失败');
          setButtonsDisabled(false);
        }
      });
    });
  });

  btnAiOrganize.addEventListener('click', function () {
    saveSettings();
    var ai = getAiSettings();
    if (!ai.apiUrl || !ai.apiKey) {
      showStatus('error', '请先填写 API 地址和 Key');
      aiSection.classList.add('visible');
      toggleAi.textContent = '收起设置';
      return;
    }

    showStatus('loading', '正在抓取并交给AI整理...');
    setButtonsDisabled(true);
    hideProgress();

    getCurrentTab(function (tab) {
      chrome.runtime.sendMessage({
        action: 'aiOrganize',
        tabId: tab.id,
        format: currentFormat,
        aiSettings: ai
      }, function (resp) {
        if (resp && resp.started) {
          startPolling();
        } else {
          showStatus('error', '启动失败');
          setButtonsDisabled(false);
        }
      });
    });
  });

  btnStopCrawl.addEventListener('click', function () {
    chrome.runtime.sendMessage({ action: 'stopCrawl' }, function () {
      showStatus('loading', '正在停止...');
    });
  });

  chrome.runtime.sendMessage({ action: 'getCrawlStatus' }, function (state) {
    if (state && state.isCrawling) {
      setButtonsDisabled(true);
      startPolling();
    }
  });
})();
