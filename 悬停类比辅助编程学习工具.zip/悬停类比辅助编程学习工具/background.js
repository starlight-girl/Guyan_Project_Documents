var crawlState = {
  isCrawling: false,
  pages: [],
  currentPage: 0,
  totalPages: 0,
  status: 'idle',
  message: '',
  nextSelector: '',
  tocSelector: '',
  mode: 'next',
  maxPages: 20,
  tabId: null,
  stopRequested: false,
  format: 'html'
};

function delay(ms) {
  return new Promise(function (resolve) { setTimeout(resolve, ms); });
}

function arrayBufferToBase64(buffer) {
  var binary = '';
  var bytes = new Uint8Array(buffer);
  var chunkSize = 8192;
  for (var i = 0; i < bytes.length; i += chunkSize) {
    var chunk = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

async function fetchImageAsBase64(url) {
  try {
    var response = await fetch(url, { mode: 'cors', credentials: 'omit' });
    if (!response.ok) return null;
    var contentType = response.headers.get('content-type') || 'image/png';
    if (!contentType.startsWith('image/')) {
      var extMatch = url.match(/\.(png|jpg|jpeg|gif|webp|svg|bmp)/i);
      if (extMatch) {
        var mimeMap = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', bmp: 'image/bmp' };
        contentType = mimeMap[extMatch[1].toLowerCase()] || 'image/png';
      } else {
        contentType = 'image/png';
      }
    }
    var buffer = await response.arrayBuffer();
    var base64 = arrayBufferToBase64(buffer);
    return 'data:' + contentType + ';base64,' + base64;
  } catch (e) {
    return null;
  }
}

async function embedImages(html, images) {
  var imageMap = {};
  var uniqueImages = [];
  for (var i = 0; i < images.length; i++) {
    if (!imageMap[images[i]]) {
      imageMap[images[i]] = true;
      uniqueImages.push(images[i]);
    }
  }

  crawlState.message = '正在下载图片 (0/' + uniqueImages.length + ')';

  var batchSize = 5;
  for (var b = 0; b < uniqueImages.length; b += batchSize) {
    if (crawlState.stopRequested) break;
    var batch = uniqueImages.slice(b, b + batchSize);
    var results = await Promise.all(batch.map(function (url) {
      return fetchImageAsBase64(url);
    }));
    for (var j = 0; j < batch.length; j++) {
      if (results[j]) {
        html = html.split(batch[j]).join(results[j]);
      }
    }
    crawlState.message = '正在下载图片 (' + Math.min(b + batchSize, uniqueImages.length) + '/' + uniqueImages.length + ')';
  }

  return html;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function htmlToMarkdown(html) {
  var md = html;
  md = md.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, function (m, c) { return '\n\n# ' + stripTags(c).trim() + '\n\n'; });
  md = md.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, function (m, c) { return '\n\n## ' + stripTags(c).trim() + '\n\n'; });
  md = md.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, function (m, c) { return '\n\n### ' + stripTags(c).trim() + '\n\n'; });
  md = md.replace(/<h4[^>]*>([\s\S]*?)<\/h4>/gi, function (m, c) { return '\n\n#### ' + stripTags(c).trim() + '\n\n'; });
  md = md.replace(/<h5[^>]*>([\s\S]*?)<\/h5>/gi, function (m, c) { return '\n\n##### ' + stripTags(c).trim() + '\n\n'; });
  md = md.replace(/<h6[^>]*>([\s\S]*?)<\/h6>/gi, function (m, c) { return '\n\n###### ' + stripTags(c).trim() + '\n\n'; });
  md = md.replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, function (m, c) {
    var lang = '';
    var langMatch = m.match(/class="[^"]*language-(\w+)[^"]*"/i);
    if (langMatch) lang = langMatch[1];
    return '\n\n```' + lang + '\n' + decodeHtml(c.trim()) + '\n```\n\n';
  });
  md = md.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, function (m, c) { return '\n\n```\n' + decodeHtml(stripTags(c).trim()) + '\n```\n\n'; });
  md = md.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, function (m, c) { return '`' + stripTags(c).trim() + '`'; });
  md = md.replace(/<img[^>]*src="([^"]*)"[^>]*alt="([^"]*)"[^>]*\/?>/gi, function (m, src, alt) { return '\n\n![' + alt + '](' + src + ')\n\n'; });
  md = md.replace(/<img[^>]*alt="([^"]*)"[^>]*src="([^"]*)"[^>]*\/?>/gi, function (m, alt, src) { return '\n\n![' + alt + '](' + src + ')\n\n'; });
  md = md.replace(/<img[^>]*src="([^"]*)"[^>]*\/?>/gi, function (m, src) { return '\n\n![]( ' + src + ')\n\n'; });
  md = md.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, '**$1**');
  md = md.replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, '**$1**');
  md = md.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, '*$1*');
  md = md.replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, '*$1*');
  md = md.replace(/<a[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi, '[$2]($1)');
  md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, function (m, c) {
    return c.split('\n').map(function (l) { return '> ' + l.trim(); }).join('\n') + '\n\n';
  });
  md = md.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, '- $1\n');
  md = md.replace(/<hr[^>]*\/?>/gi, '\n\n---\n\n');
  md = md.replace(/<br[^>]*\/?>/gi, '\n');
  md = md.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, '\n\n$1\n\n');
  md = md.replace(/<div[^>]*>([\s\S]*?)<\/div>/gi, '$1\n');
  md = md.replace(/<[^>]+>/g, '');
  md = decodeHtml(md);
  md = md.replace(/\n{4,}/g, '\n\n\n');
  md = md.replace(/^\s+|\s+$/g, '');
  return md;
}

function stripTags(html) {
  return html.replace(/<[^>]+>/g, '');
}

function decodeHtml(str) {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ');
}

function generateHtmlDoc(pages) {
  var parts = [];
  parts.push('<!DOCTYPE html>');
  parts.push('<html>');
  parts.push('<head>');
  parts.push('<meta charset="utf-8">');
  parts.push('<title>' + escapeHtml(pages[0].title) + '</title>');
  parts.push('<style>');
  parts.push('@page { margin: 2cm; }');
  parts.push('body { font-family: "Microsoft YaHei", "SimSun", "PingFang SC", sans-serif; font-size: 14px; line-height: 1.8; color: #333; max-width: 900px; margin: 0 auto; padding: 20px; }');
  parts.push('h1 { font-size: 24px; border-bottom: 2px solid #e94560; padding-bottom: 8px; margin-top: 30px; }');
  parts.push('h2 { font-size: 20px; border-bottom: 1px solid #ddd; padding-bottom: 6px; margin-top: 28px; }');
  parts.push('h3 { font-size: 17px; margin-top: 24px; }');
  parts.push('h4 { font-size: 15px; margin-top: 20px; }');
  parts.push('img { max-width: 100%; height: auto; display: block; margin: 12px 0; }');
  parts.push('a { color: #0f3460; text-decoration: underline; }');
  parts.push('blockquote { border-left: 4px solid #e94560; padding-left: 16px; margin-left: 0; color: #666; }');
  parts.push('.page-break { page-break-before: always; }');
  parts.push('.page-header { background: #f8f8f8; padding: 8px 16px; border-radius: 4px; margin-bottom: 20px; font-size: 12px; color: #888; border-left: 3px solid #e94560; }');
  parts.push('</style>');
  parts.push('</head>');
  parts.push('<body>');

  for (var i = 0; i < pages.length; i++) {
    if (i > 0) {
      parts.push('<div class="page-break"></div>');
    }
    parts.push('<div class="page-header">');
    parts.push('第 ' + (i + 1) + ' 节 | 来源: ' + escapeHtml(pages[i].url));
    parts.push('</div>');
    parts.push('<h1>' + escapeHtml(pages[i].title) + '</h1>');
    parts.push(pages[i].html);
  }

  parts.push('</body>');
  parts.push('</html>');
  return parts.join('\n');
}

function generateWordDoc(pages) {
  var parts = [];
  parts.push('<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">');
  parts.push('<head>');
  parts.push('<meta charset="utf-8">');
  parts.push('<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->');
  parts.push('<style>');
  parts.push('@page { margin: 2.54cm; }');
  parts.push('body { font-family: "Microsoft YaHei", "SimSun", sans-serif; font-size: 12pt; line-height: 1.8; color: #333; }');
  parts.push('h1 { font-size: 22pt; font-weight: bold; border-bottom: 2px solid #e94560; padding-bottom: 6pt; margin-top: 24pt; }');
  parts.push('h2 { font-size: 16pt; font-weight: bold; border-bottom: 1px solid #ddd; padding-bottom: 4pt; margin-top: 18pt; }');
  parts.push('h3 { font-size: 14pt; font-weight: bold; margin-top: 14pt; }');
  parts.push('p { margin: 6pt 0; }');
  parts.push('img { max-width: 100%; height: auto; }');
  parts.push('pre { background: #f5f5f5; border: 1px solid #ddd; padding: 10pt; font-family: Consolas, "Courier New", monospace; font-size: 10pt; white-space: pre-wrap; word-wrap: break-word; }');
  parts.push('code { font-family: Consolas, "Courier New", monospace; font-size: 10pt; }');
  parts.push('table { border-collapse: collapse; width: 100%; }');
  parts.push('th, td { border: 1px solid #999; padding: 6pt 8pt; }');
  parts.push('th { background: #f0f0f0; }');
  parts.push('blockquote { border-left: 3pt solid #e94560; padding-left: 12pt; color: #666; margin-left: 0; }');
  parts.push('.page-break { page-break-before: always; }');
  parts.push('.section-header { background: #f8f8f8; padding: 6pt 12pt; border-left: 3pt solid #e94560; margin-bottom: 12pt; font-size: 9pt; color: #888; }');
  parts.push('</style>');
  parts.push('</head>');
  parts.push('<body>');

  for (var i = 0; i < pages.length; i++) {
    if (i > 0) {
      parts.push('<br clear="all" style="page-break-before:always" />');
    }
    parts.push('<div class="section-header">');
    parts.push('第 ' + (i + 1) + ' 节 | 来源: ' + escapeHtml(pages[i].url));
    parts.push('</div>');
    parts.push('<h1>' + escapeHtml(pages[i].title) + '</h1>');
    parts.push(pages[i].html);
  }

  parts.push('</body>');
  parts.push('</html>');
  return parts.join('\n');
}

function downloadFile(content, title, format) {
  var mimeType, ext;
  if (format === 'doc') {
    mimeType = 'application/msword';
    ext = '.doc';
  } else if (format === 'md') {
    mimeType = 'text/markdown;charset=utf-8';
    ext = '.md';
  } else {
    mimeType = 'text/html;charset=utf-8';
    ext = '.html';
  }

  var blob = new Blob([content], { type: mimeType });
  var url = URL.createObjectURL(blob);
  var filename = title.replace(/[\\/:*?"<>|]/g, '_').substring(0, 80) + ext;

  chrome.downloads.download({
    url: url,
    filename: filename,
    saveAs: true
  }, function (downloadId) {
    if (chrome.runtime.lastError) {
      crawlState.status = 'error';
      crawlState.message = '下载失败: ' + chrome.runtime.lastError.message;
    } else {
      crawlState.status = 'done';
      crawlState.message = '完成！已保存为 ' + filename;
    }
    crawlState.isCrawling = false;
  });
}

async function processAndDownload(pages, format) {
  crawlState.status = 'processing';
  crawlState.message = '正在处理图片...';

  var allImages = [];
  for (var p = 0; p < pages.length; p++) {
    allImages = allImages.concat(pages[p].images);
  }

  var html;
  if (format === 'doc') {
    html = generateWordDoc(pages);
  } else {
    html = generateHtmlDoc(pages);
  }

  html = await embedImages(html, allImages);

  var docTitle = pages.length > 1
    ? pages[0].title + '等' + pages.length + '节'
    : pages[0].title;

  if (format === 'md') {
    var mdContent = '# ' + docTitle + '\n\n';
    for (var i = 0; i < pages.length; i++) {
      if (i > 0) mdContent += '\n\n---\n\n';
      mdContent += '## ' + pages[i].title + '\n\n';
      mdContent += '> 来源: ' + pages[i].url + '\n\n';
      mdContent += htmlToMarkdown(pages[i].html);
    }
    mdContent = mdContent.replace(/\n{4,}/g, '\n\n\n');
    downloadFile(mdContent, docTitle, 'md');
  } else {
    downloadFile(html, docTitle, format);
  }
}

async function callAiApi(content, aiSettings) {
  var systemPrompt = '你是一个专业的文档整理助手。用户会给你从网页抓取的原始内容（HTML格式），请你完成以下任务：\n' +
    '1. 识别文档类型（教程、API文档、课程、技术文章等）\n' +
    '2. 重新组织内容结构：添加合适的章节标题，归类相关内容\n' +
    '3. 优化排版：代码块加编号和说明，图片加描述，表格对齐\n' +
    '4. 重要：绝对不能删减任何内容，所有文字、代码、图片都必须保留\n' +
    '5. 输出格式：返回整理后的HTML内容（不需要html/head/body标签，只返回body内的内容）\n' +
    '6. 用中文回复';

  if (aiSettings.aiPrompt) {
    systemPrompt += '\n\n用户额外要求：' + aiSettings.aiPrompt;
  }

  var textContent = content;
  if (textContent.length > 60000) {
    textContent = textContent.substring(0, 60000) + '\n\n... [内容过长已截断，原始内容已完整保存]';
  }

  var body = {
    model: aiSettings.aiModel || 'gpt-4o-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: '请整理以下文档内容：\n\n' + textContent }
    ],
    temperature: 0.3
  };

  var response = await fetch(aiSettings.apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + aiSettings.apiKey
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    var errText = await response.text();
    throw new Error('API返回错误 (' + response.status + '): ' + errText.substring(0, 200));
  }

  var data = await response.json();

  if (data.choices && data.choices[0] && data.choices[0].message) {
    return data.choices[0].message.content;
  }

  if (data.output && data.output.choices && data.output.choices[0]) {
    return data.output.choices[0].message.content;
  }

  throw new Error('API返回格式异常: ' + JSON.stringify(data).substring(0, 200));
}

async function injectAndExtract(tabId, action, nextSelector) {
  return new Promise(function (resolve) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }, function () {
      if (chrome.runtime.lastError) {
        resolve({ success: false, error: chrome.runtime.lastError.message });
        return;
      }
      setTimeout(function () {
        chrome.tabs.sendMessage(tabId, { action: action, nextSelector: nextSelector }, function (response) {
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
          } else {
            resolve(response || { success: false, error: '无响应' });
          }
        });
      }, 500);
    });
  });
}

async function waitForTabLoad(tabId) {
  return new Promise(function (resolve) {
    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function startCrawl(tabId, maxPages, nextSelector, tocSelector, mode, format) {
  crawlState.isCrawling = true;
  crawlState.pages = [];
  crawlState.currentPage = 0;
  crawlState.maxPages = maxPages;
  crawlState.nextSelector = nextSelector;
  crawlState.tocSelector = tocSelector;
  crawlState.mode = mode;
  crawlState.tabId = tabId;
  crawlState.stopRequested = false;
  crawlState.status = 'crawling';
  crawlState.format = format;

  var urls = [];

  if (mode === 'toc' && tocSelector) {
    crawlState.message = '正在提取目录链接...';
    var tocResult = await injectAndExtract(tabId, 'extractTocLinks', null);
    if (tocResult.success && tocResult.links && tocResult.links.length > 0) {
      urls = tocResult.links;
      crawlState.totalPages = urls.length;
    } else {
      crawlState.status = 'error';
      crawlState.message = '未找到目录链接，请检查选择器';
      crawlState.isCrawling = false;
      return;
    }
  } else {
    crawlState.totalPages = maxPages;
  }

  for (var i = 0; i < (urls.length || 1); i++) {
    if (crawlState.stopRequested) {
      crawlState.message = '已停止（已抓取 ' + crawlState.pages.length + ' 页）';
      break;
    }

    if (mode === 'toc' && urls[i]) {
      crawlState.message = '正在抓取第 ' + (i + 1) + '/' + urls.length + ' 页...';
      chrome.tabs.update(tabId, { url: urls[i].url });
      await waitForTabLoad(tabId);
      await delay(1000);
    } else {
      crawlState.message = '正在抓取第 ' + (i + 1) + ' 页...';
    }

    crawlState.currentPage = i + 1;

    var result = await injectAndExtract(tabId, 'extractPage', nextSelector);

    if (!result.success) {
      crawlState.message = '第 ' + (i + 1) + ' 页提取失败: ' + result.error;
      if (mode !== 'toc') break;
      continue;
    }

    crawlState.pages.push(result.data);

    if (mode === 'next') {
      if (!result.data.nextUrl) {
        crawlState.message = '没有下一页了，共 ' + crawlState.pages.length + ' 页';
        break;
      }
      if (i + 1 >= maxPages) {
        crawlState.message = '已达到最大页数限制 (' + maxPages + ')';
        break;
      }
      chrome.tabs.update(tabId, { url: result.data.nextUrl });
      await waitForTabLoad(tabId);
      await delay(1000);
    }
  }

  if (crawlState.pages.length === 0) {
    crawlState.status = 'error';
    crawlState.message = '没有抓取到任何内容';
    crawlState.isCrawling = false;
    return;
  }

  await processAndDownload(crawlState.pages, format);
}

async function grabSinglePage(tabId, format) {
  crawlState.isCrawling = true;
  crawlState.status = 'crawling';
  crawlState.message = '正在抓取...';
  crawlState.pages = [];
  crawlState.currentPage = 1;
  crawlState.format = format;

  var result = await injectAndExtract(tabId, 'extractPage', '');

  if (!result.success) {
    crawlState.status = 'error';
    crawlState.message = '抓取失败: ' + result.error;
    crawlState.isCrawling = false;
    return;
  }

  crawlState.pages.push(result.data);
  await processAndDownload(crawlState.pages, format);
}

async function grabSelection(tabId, format) {
  crawlState.isCrawling = true;
  crawlState.status = 'crawling';
  crawlState.message = '正在抓取选区...';
  crawlState.format = format;

  var result = await injectAndExtract(tabId, 'extractSelection', '');

  if (!result.success) {
    crawlState.status = 'error';
    crawlState.message = result.error || '抓取失败';
    crawlState.isCrawling = false;
    return;
  }

  var pages = [result.data];
  await processAndDownload(pages, format);
}

async function aiOrganize(tabId, format, aiSettings) {
  crawlState.isCrawling = true;
  crawlState.status = 'crawling';
  crawlState.message = '正在抓取内容...';
  crawlState.pages = [];
  crawlState.format = format;

  var result = await injectAndExtract(tabId, 'extractPage', '');

  if (!result.success) {
    crawlState.status = 'error';
    crawlState.message = '抓取失败: ' + result.error;
    crawlState.isCrawling = false;
    return;
  }

  crawlState.pages.push(result.data);

  crawlState.status = 'processing';
  crawlState.message = '正在嵌入图片...';

  var allImages = result.data.images;
  var rawHtml = result.data.html;
  rawHtml = await embedImages(rawHtml, allImages);

  crawlState.message = '正在交给AI整理，请稍候...';

  try {
    var aiResult = await callAiApi(rawHtml, aiSettings);

    var cleanedAiResult = aiResult;
    cleanedAiResult = cleanedAiResult.replace(/^```html?\n?/i, '').replace(/\n?```$/i, '');
    cleanedAiResult = cleanedAiResult.replace(/^<html[\s\S]*?<body>/i, '').replace(/<\/body>[\s\S]*<\/html>/i, '');

    crawlState.pages[0].html = cleanedAiResult;

    await processAndDownload(crawlState.pages, format);
  } catch (e) {
    crawlState.status = 'error';
    crawlState.message = 'AI整理失败: ' + e.message;
    crawlState.isCrawling = false;
  }
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === 'grabSingle') {
    grabSinglePage(request.tabId, request.format || 'html');
    sendResponse({ started: true });
  }

  if (request.action === 'grabSelection') {
    grabSelection(request.tabId, request.format || 'html');
    sendResponse({ started: true });
  }

  if (request.action === 'startCrawl') {
    startCrawl(
      request.tabId,
      request.maxPages || 20,
      request.nextSelector || '',
      request.tocSelector || '',
      request.mode || 'next',
      request.format || 'html'
    );
    sendResponse({ started: true });
  }

  if (request.action === 'aiOrganize') {
    aiOrganize(
      request.tabId,
      request.format || 'html',
      request.aiSettings || {}
    );
    sendResponse({ started: true });
  }

  if (request.action === 'stopCrawl') {
    crawlState.stopRequested = true;
    sendResponse({ stopped: true });
  }

  if (request.action === 'getCrawlStatus') {
    sendResponse({
      isCrawling: crawlState.isCrawling,
      status: crawlState.status,
      message: crawlState.message,
      currentPage: crawlState.currentPage,
      totalPages: crawlState.totalPages,
      pageCount: crawlState.pages.length
    });
  }
});
